"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Crosshair,
  Eye,
  EyeOff,
  LocateFixed,
  Minus,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { RECEPTION_ROOM } from "@/lib/prison/reception";
import { drawIllustratedReception } from "@/lib/prison/render-illustrated";
import { projectWorldPoint } from "@/lib/prison/render-isometric";
import type {
  Character,
  Hotspot,
  Point,
  SelectedEntity,
} from "@/lib/prison/types";

const WORLD = { width: 1600, height: 1000 };
const CYCLE_SECONDS = 110;

type Camera = { x: number; y: number; zoom: number };
type CharacterFrame = { character: Character; point: Point; activity: string; line?: string };
type Hovered = { name: string; x: number; y: number } | null;

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const ease = (value: number) => value * value * (3 - 2 * value);

function getCharacterFrame(character: Character, cycleTime: number): CharacterFrame {
  const routine = character.routine;
  let index = routine.length - 1;
  for (let i = 0; i < routine.length; i += 1) {
    if (routine[i].at <= cycleTime) index = i;
  }

  const current = routine[index];
  const next = routine[(index + 1) % routine.length];
  const currentAt = current.at;
  const nextAt = index === routine.length - 1 ? next.at + CYCLE_SECONDS : next.at;
  const normalizedTime = cycleTime < currentAt ? cycleTime + CYCLE_SECONDS : cycleTime;
  const travelDuration = Math.min(9, Math.max(4, (nextAt - currentAt) * 0.38));
  const travelStart = nextAt - travelDuration;
  const routeDistance = Math.hypot(
    next.point.x - current.point.x,
    next.point.y - current.point.y,
  );
  const moving = normalizedTime >= travelStart && routeDistance > 1;
  const movement = moving
    ? ease(clamp((normalizedTime - travelStart) / travelDuration, 0, 1))
    : 0;
  const planPoint = {
    x: current.point.x + (next.point.x - current.point.x) * movement,
    y: current.point.y + (next.point.y - current.point.y) * movement,
  };
  const lineAge = normalizedTime - currentAt;

  return {
    character,
    point: projectWorldPoint(planPoint),
    activity: moving ? `Se déplace — ${next.activity.toLowerCase()}` : current.activity,
    line: !moving && current.line && lineAge > 2 && lineAge < 8 ? current.line : undefined,
  };
}

function rect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, color: string) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function strokeRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string,
  lineWidth = 2,
) {
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.strokeRect(Math.round(x) + 0.5, Math.round(y) + 0.5, Math.round(w), Math.round(h));
}

function pixelText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  color: string,
  size = 13,
  align: CanvasTextAlign = "left",
) {
  ctx.font = `700 ${size}px "Courier New", monospace`;
  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#10171c";
  ctx.fillText(text, x + 2, y + 2);
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

function drawFloor(ctx: CanvasRenderingContext2D) {
  rect(ctx, 180, 120, 1240, 760, "#9ca79d");
  for (let y = 168; y < 880; y += 32) {
    for (let x = 216; x < 1420; x += 32) {
      const alternate = ((x - 216) / 32 + (y - 168) / 32) % 2 === 0;
      rect(ctx, x, y, 31, 31, alternate ? "#aeb6aa" : "#a8b1a6");
      rect(ctx, x, y + 30, 31, 1, "#7c8982");
      rect(ctx, x + 30, y, 1, 31, "#c3c9bd");
      if ((x * 3 + y) % 224 === 0) rect(ctx, x + 8, y + 12, 3, 2, "#859188");
    }
  }

  // Arrival guide line and floor lettering.
  rect(ctx, 692, 594, 284, 5, "#d2b45b");
  for (let x = 692; x < 976; x += 24) rect(ctx, x, 594, 12, 5, "#f0d476");
  pixelText(ctx, "ATTENTE / ADMISSION", 835, 626, "#68736e", 12, "center");

  // Rug at the public entrance.
  rect(ctx, 700, 774, 212, 72, "#34464a");
  rect(ctx, 708, 782, 196, 56, "#29393d");
  pixelText(ctx, "PRSION—19", 806, 810, "#91a7a2", 15, "center");
}

function drawArchitecture(ctx: CanvasRenderingContext2D) {
  // Deep cast shadow and exterior service grid.
  rect(ctx, 206, 155, 1250, 758, "rgba(0,0,0,.35)");

  // Top wall depth.
  rect(ctx, 180, 98, 1240, 62, "#303b40");
  rect(ctx, 180, 98, 1240, 13, "#5a676a");
  rect(ctx, 180, 146, 1240, 14, "#1b252b");
  for (let x = 205; x < 1400; x += 96) rect(ctx, x, 108, 3, 38, "#242e33");

  // Left wall depth.
  rect(ctx, 156, 98, 60, 782, "#374247");
  rect(ctx, 156, 98, 15, 782, "#606b6d");
  rect(ctx, 204, 160, 12, 720, "#20292e");

  // Right cutaway wall with future opening.
  rect(ctx, 1406, 98, 36, 345, "#3c484d");
  rect(ctx, 1406, 617, 36, 263, "#3c484d");
  rect(ctx, 1418, 98, 24, 782, "#222d32");
  rect(ctx, 1398, 432, 20, 194, "#1b2428");
  rect(ctx, 1424, 432, 18, 194, "#58666a");

  // Bottom cutaway wall and entry opening.
  rect(ctx, 156, 868, 532, 38, "#313d42");
  rect(ctx, 922, 868, 520, 38, "#313d42");
  rect(ctx, 156, 894, 532, 12, "#1b2529");
  rect(ctx, 922, 894, 520, 12, "#1b2529");

  // Main secure door on the top wall.
  rect(ctx, 696, 108, 184, 57, "#111a1f");
  rect(ctx, 708, 113, 160, 50, "#526066");
  rect(ctx, 718, 119, 62, 42, "#26363d");
  rect(ctx, 794, 119, 62, 42, "#26363d");
  rect(ctx, 786, 118, 4, 44, "#151d21");
  rect(ctx, 749, 132, 4, 14, "#7d969a");
  rect(ctx, 823, 132, 4, 14, "#7d969a");
  pixelText(ctx, "A—01", 788, 87, "#d9bd68", 13, "center");

  // Observation windows.
  for (const x of [334, 480, 1042, 1188]) {
    rect(ctx, x, 112, 105, 37, "#0d1a21");
    rect(ctx, x + 7, 117, 91, 27, "#31505a");
    rect(ctx, x + 14, 120, 28, 22, "#3d6570");
    rect(ctx, x + 55, 120, 36, 3, "#6d8990");
  }

  // Public entrance airlock.
  rect(ctx, 678, 858, 254, 24, "#151e23");
  rect(ctx, 688, 846, 234, 19, "#536166");
  for (let x = 703; x < 922; x += 24) rect(ctx, x, 849, 5, 14, "#243036");
  rect(ctx, 684, 840, 8, 30, "#9aa7a4");
  rect(ctx, 918, 840, 8, 30, "#9aa7a4");
}

function drawLights(ctx: CanvasRenderingContext2D, time: number) {
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  for (const [x, y] of [
    [410, 300],
    [800, 292],
    [1190, 300],
    [410, 650],
    [800, 680],
    [1190, 650],
  ]) {
    const gradient = ctx.createRadialGradient(x, y, 6, x, y, 145);
    gradient.addColorStop(0, "rgba(255,239,183,.12)");
    gradient.addColorStop(1, "rgba(255,239,183,0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(x - 150, y - 150, 300, 300);
    rect(ctx, x - 34, y - 5, 68, 10, "rgba(255,246,204,.44)");
    rect(ctx, x - 28, y - 3, 56, 5, "rgba(255,255,226,.7)");
  }
  const flicker = Math.floor(time * 7) % 19 === 0 ? 0.08 : 0.16;
  rect(ctx, 1090, 176, 135, 86, `rgba(79,211,196,${flicker})`);
  ctx.restore();
}

function drawDesk(ctx: CanvasRenderingContext2D, time: number) {
  // Shadow and L-shaped desk.
  rect(ctx, 620, 434, 382, 124, "rgba(27,35,38,.38)");
  rect(ctx, 598, 395, 378, 98, "#4b5557");
  rect(ctx, 614, 380, 346, 77, "#78817d");
  rect(ctx, 614, 448, 346, 16, "#313b3d");
  rect(ctx, 598, 464, 378, 48, "#465052");
  for (let x = 621; x < 958; x += 54) rect(ctx, x, 474, 38, 5, "#667174");
  rect(ctx, 936, 452, 40, 60, "#303b3e");

  // Monitors and desk clutter.
  for (const [x, color] of [
    [676, "#68b6ad"],
    [842, "#d4aa52"],
  ] as const) {
    rect(ctx, x, 350, 90, 52, "#1a2226");
    rect(ctx, x + 6, 356, 78, 39, "#263b3e");
    rect(ctx, x + 11, 361, 40 + ((time * 7) % 22), 3, color);
    rect(ctx, x + 11, 369, 58, 3, "#758789");
    rect(ctx, x + 11, 377, 32, 3, "#758789");
    rect(ctx, x + 42, 402, 7, 14, "#222b2d");
    rect(ctx, x + 27, 413, 38, 5, "#273133");
  }
  rect(ctx, 790, 405, 32, 19, "#d9d2b8");
  rect(ctx, 796, 410, 22, 2, "#5b5f57");
  rect(ctx, 796, 415, 14, 2, "#5b5f57");
  rect(ctx, 920, 417, 12, 18, "#59483c");
  rect(ctx, 922, 413, 8, 5, "#8aa39b");
  pixelText(ctx, "ADMISSIONS", 787, 489, "#d5c073", 12, "center");
}

function drawSecurity(ctx: CanvasRenderingContext2D, time: number) {
  // Screening table and trays.
  rect(ctx, 330, 508, 200, 22, "rgba(22,29,31,.3)");
  rect(ctx, 320, 482, 210, 27, "#596568");
  rect(ctx, 330, 509, 12, 76, "#394348");
  rect(ctx, 506, 509, 12, 76, "#394348");
  for (let x = 339; x < 484; x += 52) {
    rect(ctx, x, 464, 44, 18, "#2b3c43");
    strokeRect(ctx, x + 3, 467, 38, 12, "#78929a", 2);
  }

  // Security arch.
  rect(ctx, 461, 591, 128, 18, "rgba(15,20,22,.32)");
  rect(ctx, 466, 505, 25, 122, "#263439");
  rect(ctx, 563, 505, 25, 122, "#263439");
  rect(ctx, 466, 496, 122, 24, "#45565b");
  rect(ctx, 473, 503, 108, 9, "#758588");
  rect(ctx, 472, 518, 8, 95, "#5a6a6e");
  rect(ctx, 574, 518, 8, 95, "#152126");
  const alarm = Math.floor(time) % 17 === 0;
  rect(ctx, 535, 501, 7, 7, alarm ? "#df5b43" : "#69c58d");
  rect(ctx, 547, 501, 7, 7, "#d9b357");

  // Scanner console.
  rect(ctx, 596, 552, 70, 54, "#313e43");
  rect(ctx, 603, 559, 56, 26, "#14272b");
  rect(ctx, 608, 565, 34, 3, "#5eb5a8");
  rect(ctx, 608, 573, 21, 3, "#6d8c88");
  rect(ctx, 606, 606, 7, 30, "#222c30");
  rect(ctx, 647, 606, 7, 30, "#222c30");
}

function drawWaitingArea(ctx: CanvasRenderingContext2D) {
  // Lockers.
  rect(ctx, 1152, 272, 176, 214, "rgba(21,27,29,.3)");
  rect(ctx, 1140, 252, 176, 214, "#586366");
  for (let row = 0; row < 6; row += 1) {
    for (let col = 0; col < 4; col += 1) {
      const x = 1148 + col * 40;
      const y = 260 + row * 33;
      rect(ctx, x, y, 34, 28, row === 4 && col === 2 ? "#3e474a" : "#6e7979");
      strokeRect(ctx, x, y, 34, 28, "#3a4548", 1);
      rect(ctx, x + 25, y + 12, 4, 4, row === 4 && col === 2 ? "#b95644" : "#c4b274");
      pixelText(ctx, `${row * 4 + col + 1}`.padStart(2, "0"), x + 5, y + 8, "#c5ccca", 7);
    }
  }
  pixelText(ctx, "CONSIGNES", 1228, 236, "#bfc9c6", 11, "center");

  // Three benches.
  for (const y of [560, 646, 732]) {
    rect(ctx, 1044, y + 16, 226, 30, "rgba(24,30,31,.27)");
    rect(ctx, 1028, y, 236, 25, "#45545a");
    rect(ctx, 1038, y - 8, 216, 15, "#65747a");
    rect(ctx, 1043, y + 25, 11, 34, "#27343a");
    rect(ctx, 1238, y + 25, 11, 34, "#27343a");
    for (let x = 1060; x < 1240; x += 44) rect(ctx, x, y - 5, 3, 22, "#34434a");
  }

  // Lost photograph hidden below the last bench.
  ctx.save();
  ctx.translate(1118, 747);
  ctx.rotate(-0.11);
  rect(ctx, -15, -10, 30, 21, "#d6cda9");
  rect(ctx, -11, -6, 22, 12, "#617a79");
  rect(ctx, -8, 2, 16, 4, "#26383b");
  ctx.restore();
}

function drawDetails(ctx: CanvasRenderingContext2D, time: number) {
  // Movement board.
  rect(ctx, 992, 166, 246, 105, "#182328");
  rect(ctx, 1002, 176, 226, 84, "#26363a");
  pixelText(ctx, "MOUVEMENTS", 1015, 190, "#d1bd71", 11);
  const rows = [
    ["06:42", "A-318", "EN COURS"],
    ["07:10", "T-044", "ATTENTE"],
    ["--:--", "L-019", Math.floor(time * 2) % 2 ? "?" : ""],
  ];
  rows.forEach((row, index) => {
    const y = 210 + index * 15;
    pixelText(ctx, row[0], 1015, y, "#759893", 8);
    pixelText(ctx, row[1], 1070, y, "#a9bbb5", 8);
    pixelText(ctx, row[2], 1134, y, index === 2 ? "#d9a451" : "#78ab8e", 8);
  });

  // Cameras.
  for (const [x, y, flip] of [
    [242, 181, 1],
    [1354, 200, -1],
    [1338, 812, -1],
  ] as const) {
    rect(ctx, x, y, 38, 16, "#202b30");
    rect(ctx, x + (flip === 1 ? 26 : -6), y + 4, 14, 10, "#59686c");
    rect(ctx, x + (flip === 1 ? 4 : 28), y + 5, 7, 7, "#9e3e34");
    rect(ctx, x + 16, y - 9, 5, 10, "#566368");
  }

  // Fire cabinet, clock and wall marks.
  rect(ctx, 245, 244, 72, 104, "#782f2b");
  rect(ctx, 252, 252, 58, 90, "#a94e42");
  rect(ctx, 263, 266, 36, 56, "#d6d4c4");
  rect(ctx, 269, 273, 24, 41, "#aa3c32");
  pixelText(ctx, "INC", 281, 332, "#e9c5ac", 8, "center");
  ctx.fillStyle = "#d8ded7";
  ctx.beginPath();
  ctx.arc(930, 201, 26, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#263137";
  ctx.beginPath();
  ctx.arc(930, 201, 21, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#d5c274";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(930, 201);
  ctx.lineTo(930 + Math.cos(time * 0.4) * 14, 201 + Math.sin(time * 0.4) * 14);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(930, 201);
  ctx.lineTo(921, 192);
  ctx.stroke();
  for (let i = 0; i < 5; i += 1) rect(ctx, 279 + (i % 2) * 8, 358 + i * 8, 3, 9, "#65706b");

  // Plants are prohibited; an industrial floor fan takes the corner instead.
  rect(ctx, 266, 748, 68, 64, "#344248");
  rect(ctx, 276, 758, 48, 44, "#657579");
  rect(ctx, 297, 804, 6, 29, "#303d43");
  rect(ctx, 277, 831, 46, 6, "#303d43");
  ctx.strokeStyle = "#26343a";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(300, 780, 18, 0, Math.PI * 2);
  ctx.stroke();
  const fanAngle = time * 3;
  for (let i = 0; i < 3; i += 1) {
    const angle = fanAngle + (i * Math.PI * 2) / 3;
    ctx.beginPath();
    ctx.moveTo(300, 780);
    ctx.lineTo(300 + Math.cos(angle) * 16, 780 + Math.sin(angle) * 16);
    ctx.stroke();
  }

  // East wing future marker.
  rect(ctx, 1394, 447, 26, 163, "#10191d");
  for (let y = 454; y < 605; y += 20) rect(ctx, 1398, y, 18, 9, "#536064");
  pixelText(ctx, "AILE EST", 1378, 527, "#d0b962", 10, "right");
}

function drawCharacter(ctx: CanvasRenderingContext2D, frame: CharacterFrame, selected: boolean, showLabel: boolean, time: number) {
  const { character, point } = frame;
  const bob = Math.sin(time * 7 + character.id.length) > 0 ? 0 : 2;
  const moving = frame.activity.startsWith("Se déplace");
  const stride = moving && Math.sin(time * 12 + character.id.length) > 0 ? 3 : -3;

  if (selected) {
    ctx.strokeStyle = "#f2cf69";
    ctx.lineWidth = 3;
    ctx.setLineDash([7, 5]);
    ctx.beginPath();
    ctx.ellipse(point.x, point.y + 5, 27, 14, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Shadow.
  ctx.fillStyle = "rgba(22,27,28,.34)";
  ctx.beginPath();
  ctx.ellipse(point.x + 7, point.y + 13, 18, 9, 0, 0, Math.PI * 2);
  ctx.fill();

  const y = point.y - bob;
  rect(ctx, point.x - 11, y - 30, 22, 30, character.colors.body);
  rect(ctx, point.x - 14, y - 25, 5, 18, character.colors.body);
  rect(ctx, point.x + 9, y - 25, 5, 18, character.colors.body);
  rect(ctx, point.x - 9, y - 33, 18, 5, character.colors.accent);
  rect(ctx, point.x - 8, y - 47, 16, 15, character.colors.skin);
  rect(ctx, point.x - 9, y - 50, 18, 7, character.colors.hair);
  rect(ctx, point.x - 7, y - 1, 6, 13 + stride, "#20272b");
  rect(ctx, point.x + 2, y - 1, 6, 13 - stride, "#20272b");
  rect(ctx, point.x - 5, y - 41, 3, 2, "#171c1d");
  rect(ctx, point.x + 3, y - 41, 3, 2, "#171c1d");
  if (character.role.includes("surveillance") || character.role.includes("contrôle")) {
    rect(ctx, point.x + 4, y - 25, 5, 7, "#e0b74f");
  }

  if (showLabel || selected) {
    const width = Math.max(82, character.name.length * 8 + 18);
    rect(ctx, point.x - width / 2, y - 76, width, 20, "rgba(14,21,25,.9)");
    rect(ctx, point.x - width / 2, y - 76, 3, 20, character.colors.accent);
    pixelText(ctx, character.name, point.x, y - 66, "#e9eee9", 10, "center");
  }

  if (frame.line) {
    const width = clamp(frame.line.length * 7 + 22, 118, 244);
    const bubbleX = point.x - width / 2;
    rect(ctx, bubbleX, y - 116, width, 30, "#edf0e5");
    rect(ctx, bubbleX + 8, y - 86, 10, 6, "#edf0e5");
    pixelText(ctx, frame.line, point.x, y - 101, "#28343a", 9, "center");
  }
}

function drawWorld(
  ctx: CanvasRenderingContext2D,
  time: number,
  frames: CharacterFrame[],
  selected: SelectedEntity | null,
  showLabels: boolean,
) {
  rect(ctx, 0, 0, WORLD.width, WORLD.height, "#10181d");
  for (let x = 0; x < WORLD.width; x += 40) rect(ctx, x, 0, 1, WORLD.height, "rgba(88,111,116,.08)");
  for (let y = 0; y < WORLD.height; y += 40) rect(ctx, 0, y, WORLD.width, 1, "rgba(88,111,116,.08)");

  drawArchitecture(ctx);
  drawFloor(ctx);
  drawLights(ctx, time);
  drawDesk(ctx, time);
  drawSecurity(ctx, time);
  drawWaitingArea(ctx);
  drawDetails(ctx, time);

  frames
    .slice()
    .sort((a, b) => a.point.y - b.point.y)
    .forEach((frame) =>
      drawCharacter(
        ctx,
        frame,
        selected?.kind === "character" && selected.character.id === frame.character.id,
        showLabels,
        time,
      ),
    );

  // Ambient scan line gives the surveillance-screen character without hiding detail.
  const scanY = 120 + ((time * 28) % 760);
  rect(ctx, 180, scanY, 1240, 2, "rgba(155,230,213,.035)");
}

function formatClock(simulationSeconds: number) {
  const minutes = 6 * 60 + 38 + Math.floor(simulationSeconds * 0.55);
  const hours = Math.floor(minutes / 60) % 24;
  return `${hours.toString().padStart(2, "0")}:${(minutes % 60).toString().padStart(2, "0")}`;
}

const timelineEvents = [
  "Le sas public vient de se refermer.",
  "Un dossier incomplet retarde l'admission.",
  "Le portique S-4 signale un contrôle manuel.",
  "La porte A-01 attend une seconde validation.",
  "La ligne L-019 clignote sur le tableau.",
];

export function PrisonWorld() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const backgroundRef = useRef<HTMLImageElement | null>(null);
  const characterAtlasRef = useRef<HTMLImageElement | null>(null);
  const animationRef = useRef<number | null>(null);
  const startRef = useRef<number | null>(null);
  const cameraRef = useRef<Camera>({ x: 800, y: 500, zoom: 0.75 });
  const frameRef = useRef<CharacterFrame[]>([]);
  const showLabelsRef = useRef(false);
  const dragRef = useRef({ active: false, moved: false, x: 0, y: 0 });
  const [selected, setSelected] = useState<SelectedEntity | null>(null);
  const selectedRef = useRef<SelectedEntity | null>(null);
  const [hovered, setHovered] = useState<Hovered>(null);
  const [showLabels, setShowLabels] = useState(false);
  const [zoomLabel, setZoomLabel] = useState(75);
  const [worldTime, setWorldTime] = useState(0);
  const [discovered, setDiscovered] = useState<Set<string>>(() => new Set());

  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);

  useEffect(() => {
    showLabelsRef.current = showLabels;
  }, [showLabels]);

  useEffect(() => {
    const background = new Image();
    background.decoding = "async";
    background.src = "./art/prsion19-reception-bg.png";
    backgroundRef.current = background;

    const characterAtlas = new Image();
    characterAtlas.decoding = "async";
    characterAtlas.src = "./art/prsion19-character-atlas.png";
    characterAtlasRef.current = characterAtlas;
    return () => {
      backgroundRef.current = null;
      characterAtlasRef.current = null;
    };
  }, []);

  const setCameraZoom = useCallback((newZoom: number, focal?: Point) => {
    const camera = cameraRef.current;
    const clampedZoom = clamp(newZoom, 0.38, 1.75);
    if (focal) {
      camera.x = focal.x - ((focal.x - camera.x) * camera.zoom) / clampedZoom;
      camera.y = focal.y - ((focal.y - camera.y) * camera.zoom) / clampedZoom;
    }
    camera.zoom = clampedZoom;
    setZoomLabel(Math.round(clampedZoom * 100));
  }, []);

  const resetCamera = useCallback(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper) return;
    const bounds = wrapper.getBoundingClientRect();
    const fit = clamp(Math.min(bounds.width / 1500, bounds.height / 940), 0.42, 1.05);
    cameraRef.current = { x: 800, y: 500, zoom: fit };
    setZoomLabel(Math.round(fit * 100));
  }, []);

  useEffect(() => {
    resetCamera();
  }, [resetCamera]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrapper = wrapperRef.current;
    if (!canvas || !wrapper) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const bounds = wrapper.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(bounds.width * dpr);
      canvas.height = Math.round(bounds.height * dpr);
      canvas.style.width = `${bounds.width}px`;
      canvas.style.height = `${bounds.height}px`;
    };
    resize();
    const observer = new ResizeObserver(resize);
    observer.observe(wrapper);

    const render = (now: number) => {
      if (startRef.current === null) startRef.current = now;
      const elapsed = (now - startRef.current) / 1000;
      const cycleTime = elapsed % CYCLE_SECONDS;
      const frames = RECEPTION_ROOM.characters.map((character) => getCharacterFrame(character, cycleTime));
      frameRef.current = frames;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const cssWidth = canvas.width / dpr;
      const cssHeight = canvas.height / dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, cssWidth, cssHeight);
      ctx.save();
      const camera = cameraRef.current;
      ctx.translate(cssWidth / 2, cssHeight / 2);
      ctx.scale(camera.zoom, camera.zoom);
      ctx.translate(-camera.x, -camera.y);
      drawIllustratedReception(
        ctx,
        backgroundRef.current,
        characterAtlasRef.current,
        elapsed,
        frames,
        selectedRef.current,
        showLabelsRef.current,
      );
      ctx.restore();

      animationRef.current = requestAnimationFrame(render);
    };
    animationRef.current = requestAnimationFrame(render);

    const tick = window.setInterval(() => {
      if (startRef.current !== null) setWorldTime((performance.now() - startRef.current) / 1000);
    }, 750);

    return () => {
      observer.disconnect();
      window.clearInterval(tick);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  const screenToWorld = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const bounds = canvas.getBoundingClientRect();
    const camera = cameraRef.current;
    return {
      x: (clientX - bounds.left - bounds.width / 2) / camera.zoom + camera.x,
      y: (clientY - bounds.top - bounds.height / 2) / camera.zoom + camera.y,
    };
  }, []);

  const findEntity = useCallback((point: Point) => {
    const character = frameRef.current
      .slice()
      .reverse()
      .find((frame) => {
        const anchor = frame.character.sprite.fixedPoint ?? frame.point;
        return Math.hypot(
          anchor.x - point.x,
          anchor.y - frame.character.sprite.height * 0.48 - point.y,
        ) < 40;
      });
    if (character) return { kind: "character" as const, frame: character };

    const hotspot = RECEPTION_ROOM.hotspots.find(
      (item) =>
        point.x >= item.rect.x &&
        point.x <= item.rect.x + item.rect.width &&
        point.y >= item.rect.y &&
        point.y <= item.rect.y + item.rect.height,
    );
    if (hotspot) return { kind: "hotspot" as const, hotspot };
    return null;
  }, []);

  const handlePointerDown = (event: React.PointerEvent<HTMLCanvasElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = { active: true, moved: false, x: event.clientX, y: event.clientY };
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const drag = dragRef.current;
    if (drag.active) {
      const dx = event.clientX - drag.x;
      const dy = event.clientY - drag.y;
      if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true;
      cameraRef.current.x -= dx / cameraRef.current.zoom;
      cameraRef.current.y -= dy / cameraRef.current.zoom;
      cameraRef.current.x = clamp(cameraRef.current.x, 180, 1420);
      cameraRef.current.y = clamp(cameraRef.current.y, 100, 900);
      drag.x = event.clientX;
      drag.y = event.clientY;
      setHovered(null);
      return;
    }

    const entity = findEntity(screenToWorld(event.clientX, event.clientY));
    setHovered(entity ? { name: entity.kind === "character" ? entity.frame.character.name : entity.hotspot.name, x: event.clientX, y: event.clientY } : null);
  };

  const handlePointerUp = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const wasMoved = dragRef.current.moved;
    dragRef.current.active = false;
    if (wasMoved) return;

    const entity = findEntity(screenToWorld(event.clientX, event.clientY));
    if (!entity) return;
    if (entity.kind === "character") {
      setSelected({ kind: "character", character: entity.frame.character, activity: entity.frame.activity });
    } else {
      setSelected({ kind: "hotspot", hotspot: entity.hotspot });
      if (entity.hotspot.hidden) {
        setDiscovered((current) => new Set(current).add(entity.hotspot.id));
      }
    }
  };

  const handleWheel = (event: React.WheelEvent<HTMLCanvasElement>) => {
    event.preventDefault();
    const focal = screenToWorld(event.clientX, event.clientY);
    setCameraZoom(cameraRef.current.zoom * (event.deltaY > 0 ? 0.9 : 1.1), focal);
  };

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      const camera = cameraRef.current;
      const amount = 42 / camera.zoom;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) event.preventDefault();
      if (event.key === "ArrowUp") camera.y -= amount;
      if (event.key === "ArrowDown") camera.y += amount;
      if (event.key === "ArrowLeft") camera.x -= amount;
      if (event.key === "ArrowRight") camera.x += amount;
      if (event.key === "+" || event.key === "=") setCameraZoom(camera.zoom * 1.12);
      if (event.key === "-") setCameraZoom(camera.zoom * 0.88);
      if (event.key === "0") resetCamera();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [resetCamera, setCameraZoom]);

  const hiddenTotal = useMemo(() => RECEPTION_ROOM.hotspots.filter((item) => item.hidden).length, []);
  const activeEvent = timelineEvents[Math.floor(worldTime / 12) % timelineEvents.length];
  const selectedCharacterFrame =
    selected?.kind === "character"
      ? frameRef.current.find((frame) => frame.character.id === selected.character.id)
      : null;

  return (
    <TooltipProvider>
      <main className="prison-shell">
        <header className="topbar">
          <div className="brand-lockup">
            <div className="brand-mark" aria-hidden="true">
              <span />
              <span />
              <span />
            </div>
            <div>
              <p className="brand-kicker">SURVEILLANCE / SECTEUR 01</p>
              <h1>PRSION-19</h1>
            </div>
          </div>
          <div className="room-title" aria-label="Zone observée">
            <span className="status-dot" />
            <div>
              <strong>Accueil central</strong>
              <small>6 vies autonomes · scène 01</small>
            </div>
          </div>
          <div className="sim-clock">
            <span>HEURE INTERNE</span>
            <strong>{formatClock(worldTime)}</strong>
          </div>
        </header>

        <section className="world-stage" ref={wrapperRef} aria-label="Vue aérienne interactive de l'accueil de PRSION-19">
          <canvas
            ref={canvasRef}
            className={dragRef.current.active ? "dragging" : ""}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerCancel={() => {
              dragRef.current.active = false;
            }}
            onPointerLeave={() => setHovered(null)}
            onWheel={handleWheel}
            aria-label="Scène pixel-art vivante. Faites glisser pour déplacer la caméra et cliquez sur un personnage ou un objet."
          />

          <div className="stage-vignette" aria-hidden="true" />

          <aside className="observer-card">
            <div className="observer-card__title">
              <Eye size={15} />
              <span>Regardez la scène vivre</span>
            </div>
            <p>Déplacez-vous librement dans la maquette. Chaque personnage suit sa propre journée.</p>
            <div className="hint-row">
              <span><i className="mouse-icon" /> Glisser</span>
              <span><Search size={12} /> Cliquer</span>
              <span><Crosshair size={12} /> Explorer</span>
            </div>
          </aside>

          <aside className="event-card" aria-live="polite">
            <span className="event-label">BRUIT DE FOND · {formatClock(worldTime)}</span>
            <p>{activeEvent}</p>
          </aside>

          <aside className="secrets-card">
            <Sparkles size={14} />
            <span>Détails trouvés</span>
            <strong>{discovered.size}/{hiddenTotal}</strong>
          </aside>

          <div className="camera-controls" aria-label="Contrôles de caméra">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button aria-label="Dézoomer" variant="outline" size="icon" onClick={() => setCameraZoom(cameraRef.current.zoom * 0.86)}>
                  <Minus />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">Dézoomer</TooltipContent>
            </Tooltip>
            <div className="zoom-readout">{zoomLabel}%</div>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button aria-label="Zoomer" variant="outline" size="icon" onClick={() => setCameraZoom(cameraRef.current.zoom * 1.16)}>
                  <Plus />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">Zoomer</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button aria-label="Recentrer la vue" variant="outline" size="icon" onClick={resetCamera}>
                  <LocateFixed />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">Recentrer</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button aria-label={showLabels ? "Masquer les noms" : "Afficher les noms"} variant="outline" size="icon" onClick={() => setShowLabels((value) => !value)}>
                  {showLabels ? <EyeOff /> : <Eye />}
                </Button>
              </TooltipTrigger>
              <TooltipContent side="left">{showLabels ? "Masquer les noms" : "Afficher les noms"}</TooltipContent>
            </Tooltip>
          </div>

          {hovered && (
            <div className="canvas-tooltip" style={{ left: hovered.x + 16, top: hovered.y + 16 }}>
              {hovered.name}
              <span>cliquer pour inspecter</span>
            </div>
          )}

          <div className="edge-label edge-label--east">AILE EST · PROCHAINE EXTENSION</div>
        </section>

        <footer className="bottombar">
          <div><ShieldCheck size={14} /><span>FLUX AUTONOME ACTIF</span></div>
          <p>Caméra : glisser · zoom : molette / + / − · déplacement : flèches · recentrer : 0</p>
          <span>PROTOCOLE 01.19</span>
        </footer>

        <Sheet open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
          <SheetContent className="entity-sheet" side="right">
            {selected?.kind === "character" ? (
              <>
                <SheetHeader className="entity-sheet__header">
                  <p className="sheet-eyebrow">DOSSIER / {selected.character.id.toUpperCase()}</p>
                  <div className="portrait" style={{ "--portrait": selected.character.colors.body, "--portrait-accent": selected.character.colors.accent } as React.CSSProperties}>
                    <span />
                  </div>
                  <SheetTitle>{selected.character.name}</SheetTitle>
                  <SheetDescription>{selected.character.role}</SheetDescription>
                </SheetHeader>
                <div className="entity-sheet__body">
                  <div className="live-activity">
                    <span className="status-dot" />
                    <div>
                      <small>ACTIVITÉ ACTUELLE</small>
                      <strong>{selectedCharacterFrame?.activity ?? selected.activity}</strong>
                    </div>
                  </div>
                  <section>
                    <h3>Observation</h3>
                    <p>{selected.character.description}</p>
                  </section>
                  <dl className="data-grid">
                    <div><dt>Accréditation</dt><dd>{selected.character.clearance}</dd></div>
                    <div><dt>Routine</dt><dd>{selected.character.routine.length} étapes</dd></div>
                  </dl>
                  <section>
                    <h3>Traits observés</h3>
                    <div className="trait-list">{selected.character.traits.map((trait) => <span key={trait}>{trait}</span>)}</div>
                  </section>
                  <section>
                    <h3>Routine connue</h3>
                    <ol className="routine-list">
                      {selected.character.routine.map((step) => (
                        <li key={`${selected.character.id}-${step.at}`}>
                          <time>{formatClock(step.at)}</time>
                          <span>{step.activity}</span>
                        </li>
                      ))}
                    </ol>
                  </section>
                </div>
              </>
            ) : selected?.kind === "hotspot" ? (
              <>
                <SheetHeader className="entity-sheet__header object-header">
                  <p className="sheet-eyebrow">{selected.hotspot.category.toUpperCase()}</p>
                  <div className="object-glyph"><Crosshair /></div>
                  <SheetTitle>{selected.hotspot.name}</SheetTitle>
                  <SheetDescription>{selected.hotspot.description}</SheetDescription>
                </SheetHeader>
                <div className="entity-sheet__body">
                  {selected.hotspot.hidden && (
                    <div className="secret-found"><Sparkles size={16} /> Détail caché découvert</div>
                  )}
                  <section>
                    <h3>Ce que vous remarquez</h3>
                    <p>{selected.hotspot.detail}</p>
                  </section>
                  <dl className="data-grid">
                    <div><dt>Zone</dt><dd>Accueil central</dd></div>
                    <div><dt>Référence</dt><dd>{selected.hotspot.id.toUpperCase()}</dd></div>
                  </dl>
                </div>
              </>
            ) : null}
          </SheetContent>
        </Sheet>
      </main>
    </TooltipProvider>
  );
}
