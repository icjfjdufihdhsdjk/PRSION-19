import { PrisonWorld } from "@/components/prison-world";

export default function Home() {
  return <PrisonWorld />;
}
