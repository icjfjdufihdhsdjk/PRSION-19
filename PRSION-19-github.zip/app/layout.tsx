import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PRSION-19 — Monde carcéral vivant",
  description:
    "Observez une prison fictive pixel-art qui continue de vivre sans vous. Explorez l'accueil central et ses routines autonomes.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body className="antialiased">{children}</body>
    </html>
  );
}
