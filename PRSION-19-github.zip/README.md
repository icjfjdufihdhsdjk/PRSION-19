# PRSION-19

PRSION-19 est un monde carcéral fictif et vivant en pixel-art. Le visiteur ne contrôle personne : il observe les routines autonomes des personnages, déplace la caméra, zoome et inspecte les habitants, les objets et les détails cachés.

## Version 1 — accueil central

La première scène comprend six personnages originaux : deux agents travaillent en permanence derrière les ordinateurs, un gardien contrôle le sas, des visiteurs attendent ou se déplacent et un agent de maintenance entretient les lieux. Leurs animations et routines sont autonomes. Deux détails sont cachés dans le décor.

## Organisation du projet

- `app/page.tsx` monte l'expérience principale ;
- `components/prison-world.tsx` contient la caméra, le moteur d'animation et les interactions ;
- `lib/prison/types.ts` définit le contrat commun des pièces, personnages, routines et objets ;
- `lib/prison/reception.ts` décrit uniquement les données de l'accueil ;
- `lib/prison/render-illustrated.ts` assemble le décor, la planche de sprites et les microanimations dans Canvas ;
- `public/art/` contient les deux PNG nécessaires au site : le décor et la planche de personnages.

Une nouvelle pièce peut être ajoutée comme un nouveau `RoomModule`, avec ses limites, ses points d'intérêt et ses personnages, puis enregistrée dans le monde. Le moteur de caméra et de routines n'a pas besoin d'être réécrit.

## Développement local

```bash
npm ci
npm run dev
```

## Publication sur GitHub Pages

1. Créer un dépôt GitHub et y pousser le projet sur la branche `main`.
2. Dans **Settings → Pages**, choisir **GitHub Actions** comme source.
3. Le workflow `.github/workflows/deploy-pages.yml` construit et publie automatiquement le site à chaque modification de `main`.

Le site est exporté en fichiers statiques dans `dist/client` : aucun serveur, compte utilisateur ou base de données n'est nécessaire pour cette version.

Les images sont stockées directement dans le dépôt. Le site n'appelle donc aucun service d'image ou d'intelligence artificielle une fois publié sur GitHub Pages.
