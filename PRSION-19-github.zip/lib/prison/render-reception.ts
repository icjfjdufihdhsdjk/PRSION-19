import type { Character, Point, SelectedEntity } from "./types";

export type RenderCharacterFrame = {
  character: Character;
  point: Point;
  activity: string;
  line?: string;
};

const px = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  color: string,
) => {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(width), Math.round(height));
};

const outline = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  color = "#2a3035",
  size = 3,
) => {
  ctx.strokeStyle = color;
  ctx.lineWidth = size;
  ctx.strokeRect(Math.round(x) + 0.5, Math.round(y) + 0.5, width, height);
};

const polygon = (ctx: CanvasRenderingContext2D, points: Point[], color: string) => {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  points.slice(1).forEach((point) => ctx.lineTo(point.x, point.y));
  ctx.closePath();
  ctx.fill();
};

const label = (
  ctx: CanvasRenderingContext2D,
  value: string,
  x: number,
  y: number,
  color = "#f6e5b4",
  size = 11,
  align: CanvasTextAlign = "left",
) => {
  ctx.font = `700 ${size}px "Courier New", monospace`;
  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#2a2e35";
  ctx.fillText(value, x + 2, y + 2);
  ctx.fillStyle = color;
  ctx.fillText(value, x, y);
};

function drawShell(ctx: CanvasRenderingContext2D, time: number) {
  px(ctx, 0, 0, 1600, 1000, "#273b4d");

  // A distant prison megastructure makes the first room feel like one tile of a huge world.
  for (let x = -80; x < 1680; x += 92) {
    px(ctx, x, 55, 70, 9, "#395369");
    px(ctx, x + 9, 68, 52, 4, "#192c3b");
  }
  for (let x = 10; x < 1590; x += 38) px(ctx, x, 18, 4, 20 + ((x / 38) % 3) * 6, "#182b39");

  // Building shadow, ceiling slab and open dollhouse shell.
  polygon(ctx, [
    { x: 150, y: 178 }, { x: 1408, y: 178 }, { x: 1530, y: 272 }, { x: 1530, y: 884 },
    { x: 300, y: 884 }, { x: 150, y: 770 },
  ], "rgba(13,25,31,.52)");

  polygon(ctx, [
    { x: 120, y: 112 }, { x: 1375, y: 112 }, { x: 1475, y: 183 }, { x: 235, y: 183 },
  ], "#405a61");
  polygon(ctx, [
    { x: 120, y: 112 }, { x: 235, y: 183 }, { x: 235, y: 225 }, { x: 120, y: 150 },
  ], "#263b47");
  polygon(ctx, [
    { x: 235, y: 183 }, { x: 1475, y: 183 }, { x: 1475, y: 225 }, { x: 235, y: 225 },
  ], "#2b424a");
  for (let x = 265; x < 1440; x += 82) {
    polygon(ctx, [
      { x, y: 190 }, { x: x + 51, y: 190 }, { x: x + 62, y: 198 }, { x: x + 11, y: 198 },
    ], x % 164 ? "#6e7f74" : "#8e9b82");
  }

  // Back wall with panel variation.
  px(ctx, 235, 225, 1240, 405, "#839789");
  for (let x = 235; x < 1475; x += 64) {
    px(ctx, x, 225, 2, 405, "#6f857b");
    px(ctx, x + 3, 226, 3, 404, "rgba(210,223,191,.15)");
  }
  px(ctx, 235, 392, 1240, 11, "#596f68");
  px(ctx, 235, 405, 1240, 5, "#a7b4a0");
  px(ctx, 235, 616, 1240, 14, "#425b59");

  // Floor in a clear oblique cutaway.
  polygon(ctx, [
    { x: 235, y: 630 }, { x: 1475, y: 630 }, { x: 1530, y: 858 }, { x: 310, y: 858 },
  ], "#6f887c");
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(235, 630);
  ctx.lineTo(1475, 630);
  ctx.lineTo(1530, 858);
  ctx.lineTo(310, 858);
  ctx.closePath();
  ctx.clip();
  for (let y = 630; y < 870; y += 24) {
    px(ctx, 180, y, 1400, 2, y % 48 ? "#607b72" : "#94a496");
  }
  for (let x = 100; x < 1700; x += 47) {
    ctx.strokeStyle = x % 94 ? "#5e776e" : "#9baa94";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, 620);
    ctx.lineTo(x + 70, 870);
    ctx.stroke();
  }
  ctx.restore();

  // Left and right cutaway walls.
  polygon(ctx, [
    { x: 120, y: 150 }, { x: 235, y: 225 }, { x: 235, y: 630 }, { x: 310, y: 858 },
    { x: 184, y: 768 }, { x: 120, y: 592 },
  ], "#536d6b");
  for (let y = 220; y < 700; y += 56) {
    polygon(ctx, [
      { x: 136, y }, { x: 213, y: y + 48 }, { x: 213, y: y + 55 }, { x: 136, y: y + 7 },
    ], "#304d54");
  }
  for (let i = 0; i < 7; i += 1) {
    polygon(ctx, [
      { x: 164 + (i % 2) * 5, y: 454 + i * 12 },
      { x: 169 + (i % 2) * 5, y: 457 + i * 12 },
      { x: 167 + (i % 2) * 5, y: 471 + i * 12 },
      { x: 162 + (i % 2) * 5, y: 468 + i * 12 },
    ], "#273f48");
  }
  polygon(ctx, [
    { x: 1475, y: 183 }, { x: 1512, y: 207 }, { x: 1512, y: 795 }, { x: 1530, y: 858 },
    { x: 1475, y: 630 },
  ], "#405b5c");

  // Bright utility pipes run through the whole future prison.
  px(ctx, 261, 244, 1178, 12, "#374c52");
  px(ctx, 270, 248, 1155, 4, "#e8b54f");
  px(ctx, 270, 263, 1155, 7, "#bf5d48");
  px(ctx, 270, 275, 1155, 5, "#4f95a0");
  for (let x = 300; x < 1430; x += 168) {
    px(ctx, x, 238, 5, 45, "#263b42");
    px(ctx, x - 3, 258, 11, 5, "#d8c178");
  }

  // Pixel ceiling lights and pools of warm light.
  ctx.save();
  ctx.globalCompositeOperation = "screen";
  for (const x of [390, 690, 990, 1290]) {
    const glow = ctx.createRadialGradient(x, 354, 8, x, 470, 185);
    glow.addColorStop(0, "rgba(255,239,169,.24)");
    glow.addColorStop(1, "rgba(255,239,169,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(x - 190, 280, 380, 390);
    px(ctx, x - 37, 310, 74, 10, "#f6d97f");
    px(ctx, x - 31, 313, 62, 4, "#fff2bc");
    px(ctx, x - 3, 281, 6, 29, "#384c50");
  }
  ctx.restore();

  // Low front lip gives the room a physical dollhouse edge.
  polygon(ctx, [
    { x: 310, y: 858 }, { x: 1530, y: 858 }, { x: 1530, y: 888 }, { x: 310, y: 888 },
  ], "#314b51");
  px(ctx, 310, 858, 1220, 8, "#a6a472");
  for (let x = 330; x < 1510; x += 42) px(ctx, x, 868, 22, 8, "#1f3942");

  // Slow maintenance lift visible in the outer wall.
  const liftY = 320 + (Math.sin(time * 0.34) + 1) * 95;
  px(ctx, 155, liftY, 34, 55, "#e09b42");
  px(ctx, 161, liftY + 7, 22, 31, "#284451");
  px(ctx, 166, liftY + 12, 12, 8, "#76b8b1");
}

function drawWallLife(ctx: CanvasRenderingContext2D, time: number) {
  // Administration door, with actual depth and an animated access light.
  px(ctx, 724, 344, 184, 286, "#314b55");
  px(ctx, 739, 361, 154, 269, "#567174");
  px(ctx, 751, 380, 57, 142, "#263f4c");
  px(ctx, 821, 380, 58, 142, "#263f4c");
  px(ctx, 814, 374, 5, 246, "#23383e");
  px(ctx, 778, 455, 7, 20, "#d6d49b");
  px(ctx, 850, 455, 7, 20, "#d6d49b");
  px(ctx, 785, 335, 61, 18, "#273c44");
  label(ctx, "A-01", 815, 344, "#f4cd6c", 12, "center");
  px(ctx, 902, 402, 18, 35, "#283f46");
  px(ctx, 907, 407, 8, 9, Math.floor(time * 2) % 7 ? "#78d08e" : "#f5c05b");

  // A busy movement board.
  px(ctx, 1000, 313, 232, 118, "#263a43");
  px(ctx, 1010, 323, 212, 97, "#182d36");
  label(ctx, "MOUVEMENTS", 1021, 338, "#f1c760", 11);
  const boardRows = [
    ["06:42", "A-318", "ENTRÉ"],
    ["07:10", "T-044", "ATTENTE"],
    ["--:--", "L-019", Math.floor(time * 2) % 2 ? "? ? ?" : ""],
    ["08:05", "V-201", "VISITE"],
  ];
  boardRows.forEach((row, index) => {
    const y = 356 + index * 14;
    label(ctx, row[0], 1021, y, "#7dc9b4", 8);
    label(ctx, row[1], 1070, y, "#e2e4c8", 8);
    label(ctx, row[2], 1135, y, index === 2 ? "#ff9368" : "#a8c99d", 8);
  });

  // Lockers and a tiny vending machine make the wall visually busy.
  px(ctx, 1253, 319, 167, 226, "#435e61");
  for (let row = 0; row < 6; row += 1) {
    for (let col = 0; col < 4; col += 1) {
      const x = 1261 + col * 39;
      const y = 328 + row * 34;
      px(ctx, x, y, 34, 29, row === 4 && col === 2 ? "#5a4b55" : "#708985");
      outline(ctx, x, y, 34, 29, "#314e55", 1);
      px(ctx, x + 25, y + 12, 4, 4, row === 4 && col === 2 ? "#f16a5a" : "#f0d17c");
      label(ctx, String(row * 4 + col + 1).padStart(2, "0"), x + 5, y + 8, "#dbe1c8", 7);
    }
  }
  px(ctx, 1320, 555, 100, 74, "#bc5b55");
  px(ctx, 1330, 565, 34, 48, "#203a43");
  px(ctx, 1372, 565, 36, 10, "#ffe080");
  for (let y = 583; y < 611; y += 9) px(ctx, 1375, y, 29, 4, "#e9be72");
  label(ctx, "EAU", 1347, 589, "#8bd1cc", 8, "center");

  // Original posters and institutional clutter.
  px(ctx, 300, 326, 99, 133, "#d9c98f");
  px(ctx, 308, 335, 83, 116, "#eedfa8");
  px(ctx, 317, 346, 65, 31, "#4b7f89");
  label(ctx, "ICI", 349, 362, "#f5dda0", 13, "center");
  label(ctx, "TOUT", 349, 394, "#4a5855", 11, "center");
  label(ctx, "COMPTE", 349, 411, "#b9574d", 11, "center");
  for (let i = 0; i < 5; i += 1) px(ctx, 321 + i * 12, 430, 7, 9 + (i % 2) * 4, "#6a7770");

  px(ctx, 447, 336, 85, 101, "#d3d7bb");
  px(ctx, 454, 343, 71, 87, "#f0edcb");
  label(ctx, "VISITE", 489, 355, "#b55750", 9, "center");
  for (let y = 371; y < 419; y += 10) px(ctx, 465, y, 48 - ((y / 10) % 3) * 7, 3, "#6b7772");

  // Clock and cameras.
  ctx.fillStyle = "#e5dab0";
  ctx.beginPath();
  ctx.arc(953, 355, 27, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#34515a";
  ctx.beginPath();
  ctx.arc(953, 355, 21, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#f3cf73";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(953, 355);
  ctx.lineTo(953 + Math.cos(time * 0.35) * 14, 355 + Math.sin(time * 0.35) * 14);
  ctx.moveTo(953, 355);
  ctx.lineTo(943, 347);
  ctx.stroke();

  for (const [x, flip] of [[270, 1], [1433, -1]] as const) {
    px(ctx, x, 287, 42, 16, "#263d45");
    px(ctx, x + (flip === 1 ? 30 : -5), 291, 14, 9, "#78908a");
    px(ctx, x + (flip === 1 ? 6 : 31), 291, 6, 6, Math.floor(time * 2) % 2 ? "#f15f54" : "#8a292f");
    px(ctx, x + 17, 277, 5, 11, "#31474d");
  }
}

function drawReceptionDesk(ctx: CanvasRenderingContext2D, time: number) {
  // Long counter in oblique perspective.
  polygon(ctx, [
    { x: 616, y: 548 }, { x: 1006, y: 548 }, { x: 965, y: 586 }, { x: 578, y: 586 },
  ], "#a58c67");
  polygon(ctx, [
    { x: 578, y: 586 }, { x: 965, y: 586 }, { x: 965, y: 666 }, { x: 578, y: 666 },
  ], "#596e69");
  polygon(ctx, [
    { x: 965, y: 586 }, { x: 1006, y: 548 }, { x: 1006, y: 626 }, { x: 965, y: 666 },
  ], "#3d5657");
  px(ctx, 586, 594, 371, 13, "#415b5a");
  for (let x = 598; x < 948; x += 53) {
    px(ctx, x, 619, 36, 30, "#678079");
    px(ctx, x + 4, 623, 28, 4, "#81958a");
  }
  label(ctx, "ADMISSIONS", 772, 639, "#f0ce72", 13, "center");

  // Screens, paperwork, stamp, mug, tubes: deliberately dense.
  for (const [x, color] of [[657, "#74d4c0"], [831, "#efc75e"]] as const) {
    px(ctx, x, 493, 82, 53, "#283b43");
    px(ctx, x + 6, 499, 70, 39, "#18323a");
    px(ctx, x + 11, 506, 30 + ((time * 9) % 25), 3, color);
    px(ctx, x + 11, 514, 53, 3, "#728e89");
    px(ctx, x + 11, 522, 37, 3, "#728e89");
    px(ctx, x + 38, 546, 7, 13, "#253b41");
  }
  for (let i = 0; i < 4; i += 1) {
    px(ctx, 763 + i * 7, 534 - i * 2, 42, 5, i % 2 ? "#e8dfa8" : "#b7d1c0");
  }
  px(ctx, 931, 527, 16, 21, "#c15a4c");
  px(ctx, 935, 521, 9, 7, "#314d50");
  px(ctx, 603, 541, 23, 13, "#d2c57c");
  for (let i = 0; i < 3; i += 1) px(ctx, 979, 550 + i * 13, 31, 7, "#ceb964");

  // Pneumatic tube disappears into the larger prison.
  px(ctx, 1017, 468, 25, 145, "#365058");
  px(ctx, 1023, 474, 13, 131, "#88a6a0");
  px(ctx, 1012, 463, 35, 11, "#e2b65f");
  const capsuleY = 482 + ((time * 16) % 102);
  px(ctx, 1025, capsuleY, 9, 19, "#eb8c55");
}

function drawSecurity(ctx: CanvasRenderingContext2D, time: number) {
  // Conveyor and x-ray machine.
  polygon(ctx, [
    { x: 335, y: 623 }, { x: 522, y: 623 }, { x: 542, y: 642 }, { x: 355, y: 642 },
  ], "#66807d");
  px(ctx, 355, 642, 187, 28, "#3f595d");
  for (let x = 364; x < 530; x += 18) px(ctx, x, 646, 10, 5, "#9aaca2");
  px(ctx, 335, 660, 10, 54, "#304a51");
  px(ctx, 519, 669, 10, 47, "#304a51");
  px(ctx, 326, 553, 104, 79, "#48646a");
  px(ctx, 340, 567, 76, 55, "#1b3640");
  px(ctx, 350, 576, 42, 4, "#63c1b4");
  px(ctx, 350, 586, 53, 4, "#829c96");
  px(ctx, 350, 596, 31, 4, "#829c96");
  label(ctx, "S-4", 378, 610, "#f5c85e", 9, "center");

  // Security gate reads as architecture, not a flat rectangle.
  px(ctx, 492, 497, 26, 157, "#315059");
  px(ctx, 587, 497, 26, 157, "#315059");
  px(ctx, 492, 485, 121, 27, "#5d7c78");
  px(ctx, 499, 491, 107, 9, "#9bafa2");
  px(ctx, 500, 512, 8, 128, "#72918a");
  px(ctx, 597, 512, 8, 128, "#213e48");
  px(ctx, 557, 492, 7, 7, Math.floor(time * 4) % 19 === 0 ? "#f05d4c" : "#74d192");
  px(ctx, 570, 492, 7, 7, "#f0c85f");
  polygon(ctx, [
    { x: 480, y: 654 }, { x: 617, y: 654 }, { x: 637, y: 671 }, { x: 500, y: 671 },
  ], "rgba(35,56,61,.5)");

  // Bins and original little cleaning bot.
  for (let x = 414; x < 480; x += 35) {
    px(ctx, x, 681, 29, 19, "#e4a652");
    px(ctx, x + 4, 686, 21, 4, "#5a6260");
  }
  const botX = 430 + (Math.sin(time * 0.45) + 1) * 55;
  px(ctx, botX, 760, 40, 20, "#d8c767");
  px(ctx, botX + 7, 749, 26, 13, "#49666a");
  px(ctx, botX + 12, 752, 5, 4, "#73d5c2");
  px(ctx, botX + 22, 752, 5, 4, "#73d5c2");
  px(ctx, botX + 5, 780, 8, 5, "#263f46");
  px(ctx, botX + 27, 780, 8, 5, "#263f46");
}

function drawWaiting(ctx: CanvasRenderingContext2D, time: number) {
  // Three benches in perspective with people-sized spacing.
  for (const [x, y] of [[1090, 665], [1240, 696], [1105, 770]] as const) {
    polygon(ctx, [
      { x, y }, { x: x + 130, y }, { x: x + 151, y: y + 16 }, { x: x + 21, y: y + 16 },
    ], "#8a6a55");
    px(ctx, x + 20, y + 16, 131, 21, "#496369");
    px(ctx, x + 27, y + 37, 8, 27, "#314951");
    px(ctx, x + 130, y + 37, 8, 27, "#314951");
    for (let slat = 0; slat < 4; slat += 1) px(ctx, x + 16 + slat * 32, y + 4, 25, 4, "#c39a67");
  }

  // Lost photo still exists but now lives naturally among the visual noise.
  ctx.save();
  ctx.translate(1164, 814);
  ctx.rotate(-0.17);
  px(ctx, -16, -11, 32, 23, "#f0dda4");
  px(ctx, -12, -7, 24, 14, "#62918d");
  px(ctx, -8, 2, 16, 5, "#31545b");
  ctx.restore();

  // Wall fan, paper scraps and a blinking queue dispenser.
  px(ctx, 1069, 465, 68, 68, "#4c6669");
  ctx.strokeStyle = "#29444c";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(1103, 499, 27, 0, Math.PI * 2);
  ctx.stroke();
  for (let i = 0; i < 4; i += 1) {
    const angle = time * 3.5 + (i * Math.PI) / 2;
    ctx.beginPath();
    ctx.moveTo(1103, 499);
    ctx.lineTo(1103 + Math.cos(angle) * 22, 499 + Math.sin(angle) * 22);
    ctx.stroke();
  }
  px(ctx, 1203, 581, 49, 65, "#d38d47");
  px(ctx, 1213, 591, 29, 16, "#283f47");
  label(ctx, String(18 + (Math.floor(time / 9) % 3)).padStart(2, "0"), 1227, 599, "#ffdb6b", 11, "center");
  px(ctx, 1218, 621, 19, 5, "#f1e2bd");
  for (const [x, y, color] of [[1050, 718, "#f2dfad"], [1368, 792, "#b9d4c0"], [1008, 807, "#df9664"]] as const) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(((x + y) % 11) * 0.03);
    px(ctx, -9, -5, 18, 10, color);
    ctx.restore();
  }
}

function drawSprite(
  ctx: CanvasRenderingContext2D,
  frame: RenderCharacterFrame,
  selected: boolean,
  showLabel: boolean,
  time: number,
) {
  const { character, point } = frame;
  const moving = frame.activity.startsWith("Se déplace");
  const step = moving && Math.sin(time * 12 + character.id.length) > 0 ? 2 : -2;
  const bob = moving && Math.sin(time * 12 + character.id.length) > 0 ? 1 : 0;
  const x = Math.round(point.x);
  const y = Math.round(point.y - bob);

  if (selected) {
    ctx.strokeStyle = "#ffdc67";
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.ellipse(x, y + 7, 22, 9, 0, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  ctx.fillStyle = "rgba(31,43,45,.32)";
  ctx.beginPath();
  ctx.ellipse(x + 5, y + 8, 14, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Tiny, readable sprite proportions with hard pixel clusters.
  px(ctx, x - 7, y - 31, 14, 29, character.colors.body);
  px(ctx, x - 10, y - 26, 4, 17, character.colors.body);
  px(ctx, x + 7, y - 26, 4, 17, character.colors.body);
  px(ctx, x - 6, y - 35, 12, 5, character.colors.accent);
  px(ctx, x - 6, y - 46, 12, 12, character.colors.skin);
  px(ctx, x - 7, y - 49, 14, 6, character.colors.hair);
  px(ctx, x - 5, y - 41, 2, 2, "#24282b");
  px(ctx, x + 3, y - 41, 2, 2, "#24282b");
  px(ctx, x - 6, y - 2, 5, 10 + step, "#263841");
  px(ctx, x + 2, y - 2, 5, 10 - step, "#263841");
  if (character.role.includes("surveillance") || character.role.includes("contrôle")) {
    px(ctx, x + 2, y - 26, 4, 5, "#f4cf60");
  }

  if (showLabel || selected) {
    const width = Math.max(72, character.name.length * 7 + 14);
    px(ctx, x - width / 2, y - 69, width, 17, "rgba(37,48,48,.92)");
    px(ctx, x - width / 2, y - 69, 3, 17, character.colors.accent);
    label(ctx, character.name, x, y - 60, "#fff0c8", 9, "center");
  }

  if (frame.line) {
    const width = Math.max(120, Math.min(235, frame.line.length * 7 + 20));
    px(ctx, x - width / 2, y - 105, width, 27, "#fff3c8");
    px(ctx, x - width / 2 + 8, y - 78, 9, 5, "#fff3c8");
    label(ctx, frame.line, x, y - 91, "#3d4a46", 8, "center");
  }
}

export function drawReceptionWorld(
  ctx: CanvasRenderingContext2D,
  time: number,
  frames: RenderCharacterFrame[],
  selected: SelectedEntity | null,
  showLabels: boolean,
) {
  drawShell(ctx, time);
  drawWallLife(ctx, time);
  drawReceptionDesk(ctx, time);
  drawSecurity(ctx, time);
  drawWaiting(ctx, time);

  frames
    .slice()
    .sort((a, b) => a.point.y - b.point.y)
    .forEach((frame) =>
      drawSprite(
        ctx,
        frame,
        selected?.kind === "character" && selected.character.id === frame.character.id,
        showLabels,
        time,
      ),
    );

  // Repeating exterior module connectors make expansion direction obvious.
  px(ctx, 49, 466, 95, 173, "#1f3643");
  px(ctx, 58, 480, 76, 144, "#304d58");
  for (let y = 493; y < 618; y += 22) px(ctx, 66, y, 60, 9, "#729083");
  label(ctx, "← SAS PUBLIC", 101, 655, "#f0c760", 10, "center");
  px(ctx, 1476, 452, 74, 208, "#1f3841");
  for (let y = 465; y < 645; y += 22) px(ctx, 1485, y, 57, 10, "#506d68");
  label(ctx, "AILE EST →", 1508, 678, "#f0c760", 10, "center");
}
