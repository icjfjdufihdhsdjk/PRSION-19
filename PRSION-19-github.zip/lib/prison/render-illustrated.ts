import type { Character, Point, SelectedEntity } from "./types";

export type IllustratedCharacterFrame = {
  character: Character;
  point: Point;
  activity: string;
  line?: string;
};

const WORLD = { width: 1600, height: 1000 };
const ATLAS_COLUMNS = 4;
const ATLAS_ROWS = 6;

const px = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  color: string,
) => {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(width), Math.round(height));
};

const tinyText = (
  ctx: CanvasRenderingContext2D,
  value: string,
  x: number,
  y: number,
  color = "#34575d",
) => {
  ctx.font = '700 8px "Courier New", monospace';
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgba(255,255,238,.92)";
  ctx.fillText(value, Math.round(x) + 1, Math.round(y) + 1);
  ctx.fillStyle = color;
  ctx.fillText(value, Math.round(x), Math.round(y));
};

function atlasFrame(character: Character, activity: string, time: number) {
  const moving = activity.startsWith("Se déplace");
  const rate = moving || character.sprite.animation === "clean" ? 7 : 2.2;
  return Math.floor(time * rate + character.sprite.atlasRow * 0.7) % ATLAS_COLUMNS;
}

function drawSelection(
  ctx: CanvasRenderingContext2D,
  point: Point,
  selected: boolean,
) {
  if (!selected) return;
  ctx.strokeStyle = "#e0604d";
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 2]);
  ctx.beginPath();
  ctx.ellipse(point.x, point.y + 2, 18, 8, 0.46, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
}

function drawAtlasSprite(
  ctx: CanvasRenderingContext2D,
  atlas: HTMLImageElement,
  frame: IllustratedCharacterFrame,
  selected: boolean,
  showLabel: boolean,
  time: number,
) {
  const { character } = frame;
  const point = character.sprite.fixedPoint ?? frame.point;
  // The atlas uses one half-cell of transparent breathing room on each side.
  const horizontalGutter = atlas.naturalWidth / 8;
  const cellWidth = (atlas.naturalWidth - horizontalGutter * 2) / ATLAS_COLUMNS;
  const cellHeight = atlas.naturalHeight / ATLAS_ROWS;
  const animationFrame = atlasFrame(character, frame.activity, time);

  const sourceWidth = cellWidth;
  const sourceX = horizontalGutter + animationFrame * cellWidth;
  const sourceY = character.sprite.atlasRow * cellHeight;
  const bob = frame.activity.startsWith("Se déplace")
    ? Math.floor(time * 7) % 2
    : 0;
  const destinationX = point.x - character.sprite.width / 2;
  const destinationY = point.y - character.sprite.height - bob;

  drawSelection(ctx, point, selected);
  ctx.drawImage(
    atlas,
    sourceX,
    sourceY,
    sourceWidth,
    cellHeight,
    destinationX,
    destinationY,
    character.sprite.width,
    character.sprite.height,
  );

  if (showLabel || selected) {
    const labelY = destinationY - 9;
    const width = Math.max(62, character.name.length * 6 + 10);
    px(ctx, point.x - width / 2, labelY - 7, width, 14, "rgba(250,250,229,.93)");
    px(ctx, point.x - width / 2, labelY - 7, 2, 14, character.colors.accent);
    tinyText(ctx, character.name, point.x, labelY);
  }

  if (frame.line) {
    const bubbleY = destinationY - (showLabel || selected ? 31 : 15);
    const width = Math.max(112, Math.min(220, frame.line.length * 6 + 18));
    px(ctx, point.x - width / 2, bubbleY - 12, width, 23, "#fff8d9");
    px(ctx, point.x - width / 2 + 8, bubbleY + 11, 7, 4, "#fff8d9");
    tinyText(ctx, frame.line, point.x, bubbleY, "#526866");
  }
}

function drawFallbackMarker(
  ctx: CanvasRenderingContext2D,
  frame: IllustratedCharacterFrame,
  selected: boolean,
) {
  const point = frame.character.sprite.fixedPoint ?? frame.point;
  drawSelection(ctx, point, selected);
  ctx.fillStyle = frame.character.colors.body;
  ctx.beginPath();
  ctx.arc(point.x, point.y - 18, 5, 0, Math.PI * 2);
  ctx.fill();
}

function drawMicroAnimations(ctx: CanvasRenderingContext2D, time: number) {
  const blink = Math.floor(time * 4) % 12;
  px(ctx, 1027, 406, 3, 3, blink ? "#63c891" : "#e45d58");
  px(ctx, 677, 566, 3, 3, blink % 4 ? "#62c8b4" : "#edc358");
  px(ctx, 891, 494, 18 + (time * 7) % 14, 2, "rgba(88,216,196,.55)");
  px(ctx, 918, 521, 13 + (time * 5) % 11, 2, "rgba(239,191,77,.55)");

  // Animated monitor lines make the two desk stations visibly active.
  for (const [x, y, offset] of [
    [1136, 441, 0],
    [1271, 458, 1.4],
    [1362, 428, 2.8],
  ] as const) {
    const pulse = 8 + (Math.sin(time * 2.6 + offset) + 1) * 5;
    px(ctx, x, y, pulse, 2, "rgba(92,214,191,.64)");
    px(ctx, x, y + 5, 17 - pulse / 3, 2, "rgba(242,192,87,.58)");
  }

  ctx.strokeStyle = "rgba(255,255,246,.68)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 2; i += 1) {
    const drift = Math.sin(time * 2 + i) * 2;
    ctx.beginPath();
    ctx.moveTo(952 + drift, 552 - i * 6);
    ctx.lineTo(950 - drift, 545 - i * 6);
    ctx.stroke();
  }
}

export function drawIllustratedReception(
  ctx: CanvasRenderingContext2D,
  background: HTMLImageElement | null,
  atlas: HTMLImageElement | null,
  time: number,
  frames: IllustratedCharacterFrame[],
  selected: SelectedEntity | null,
  showLabels: boolean,
) {
  const backgroundReady = Boolean(background?.complete && background.naturalWidth > 0);
  const atlasReady = Boolean(atlas?.complete && atlas.naturalWidth > 0);

  px(ctx, 0, 0, WORLD.width, WORLD.height, "#c9dfdc");
  if (backgroundReady && background) {
    const imageX = Math.round((WORLD.width - background.naturalWidth) / 2);
    const imageY = Math.round((WORLD.height - background.naturalHeight) / 2);
    ctx.drawImage(background, imageX, imageY);
  } else {
    tinyText(ctx, "CHARGEMENT DE L'ACCUEIL…", 800, 500, "#59797b");
  }

  drawMicroAnimations(ctx, time);

  const drawLayer = (layer: Character["sprite"]["layer"]) => {
    frames
      .filter((frame) => frame.character.sprite.layer === layer)
      .sort((a, b) => {
        const ay = a.character.sprite.fixedPoint?.y ?? a.point.y;
        const by = b.character.sprite.fixedPoint?.y ?? b.point.y;
        return ay - by;
      })
      .forEach((frame) => {
        const isSelected =
          selected?.kind === "character" && selected.character.id === frame.character.id;
        if (atlasReady && atlas) {
          drawAtlasSprite(ctx, atlas, frame, isSelected, showLabels, time);
        } else {
          drawFallbackMarker(ctx, frame, isSelected);
        }
      });
  };

  drawLayer("behind-desk");
  drawLayer("floor");
}
