export type Point = { x: number; y: number };

export type RoutineStep = {
  at: number;
  point: Point;
  activity: string;
  line?: string;
};

export type SpriteProfile = {
  atlasRow: number;
  animation: "desk" | "walk" | "wait" | "clean";
  layer: "behind-desk" | "floor";
  width: number;
  height: number;
  fixedPoint?: Point;
};

export type Character = {
  id: string;
  name: string;
  role: string;
  clearance: string;
  description: string;
  traits: string[];
  colors: {
    body: string;
    accent: string;
    skin: string;
    hair: string;
  };
  sprite: SpriteProfile;
  routine: RoutineStep[];
};

export type Hotspot = {
  id: string;
  name: string;
  category: string;
  description: string;
  detail: string;
  rect: { x: number; y: number; width: number; height: number };
  hidden?: boolean;
};

export type RoomModule = {
  id: string;
  name: string;
  bounds: { x: number; y: number; width: number; height: number };
  hotspots: Hotspot[];
  characters: Character[];
};

export type SelectedEntity =
  | { kind: "character"; character: Character; activity: string }
  | { kind: "hotspot"; hotspot: Hotspot };
