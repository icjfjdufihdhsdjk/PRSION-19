import type { RoomModule } from "./types";

export const RECEPTION_ROOM: RoomModule = {
  id: "reception",
  name: "Accueil central",
  bounds: { x: 180, y: 120, width: 1240, height: 760 },
  hotspots: [
    {
      id: "security-arch",
      name: "Portique S-4",
      category: "Sécurité",
      description: "Le passage obligé entre le sas public et la zone contrôlée.",
      detail:
        "Ses voyants trahissent un calibrage très sensible. Le registre indique trois déclenchements depuis le début du service.",
      rect: { x: 530, y: 475, width: 130, height: 190 },
    },
    {
      id: "reception-desk",
      name: "Banque d'admission",
      category: "Mobilier",
      description: "Le cœur administratif de l'accueil de PRSION-19.",
      detail:
        "Deux postes y croisent identités, objets consignés et autorisations. Un tube pneumatique relie le bureau au greffe.",
      rect: { x: 745, y: 465, width: 390, height: 310 },
    },
    {
      id: "sealed-door",
      name: "Porte A-01",
      category: "Accès",
      description: "Elle mène au couloir administratif, encore hors champ.",
      detail:
        "La serrure ne s'ouvre qu'après une double validation : badge du poste d'accueil et contrôle depuis la salle de surveillance.",
      rect: { x: 1035, y: 325, width: 170, height: 305 },
    },
    {
      id: "visitor-lockers",
      name: "Consignes visiteurs",
      category: "Service",
      description: "Quarante-huit casiers numérotés pour les effets personnels.",
      detail:
        "Le casier 19 est condamné. Personne ne semble se souvenir de la date à laquelle sa clé a disparu.",
      rect: { x: 1190, y: 350, width: 225, height: 335 },
    },
    {
      id: "arrival-board",
      name: "Tableau des mouvements",
      category: "Information",
      description: "Une matrice d'affichage tenue volontairement très vague.",
      detail:
        "Elle n'affiche jamais les noms : seulement des codes, une heure prévue et un statut. La ligne 19 clignote sans destination.",
      rect: { x: 875, y: 275, width: 210, height: 205 },
    },
    {
      id: "lost-photo",
      name: "Photographie froissée",
      category: "Détail caché",
      description: "Un petit tirage coincé sous la troisième banquette.",
      detail:
        "On y distingue cinq silhouettes devant un phare. Au dos, une date a été grattée et remplacée par le nombre 19.",
      rect: { x: 862, y: 792, width: 55, height: 48 },
      hidden: true,
    },
    {
      id: "wall-mark",
      name: "Marque dans le mur",
      category: "Détail caché",
      description: "Une suite de traits presque recouverte par la peinture.",
      detail:
        "Les groupes de marques ne comptent pas des jours. Leur rythme reproduit peut-être un plan ou une séquence.",
      rect: { x: 420, y: 345, width: 105, height: 145 },
      hidden: true,
    },
    {
      id: "future-east",
      name: "Aile Est — verrouillée",
      category: "Extension future",
      description: "Au-delà : contrôle, parloirs et infirmerie.",
      detail:
        "Cette zone sera raccordée à la scène dans une prochaine extension sans modifier le fonctionnement de l'accueil.",
      rect: { x: 1135, y: 615, width: 260, height: 275 },
    },
  ],
  characters: [
    {
      id: "luc-arven",
      name: "Luc Arven",
      role: "Agent des admissions",
      clearance: "Niveau ambre",
      description:
        "Installé derrière le premier ordinateur, il saisit chaque entrée sans jamais quitter le sas des yeux.",
      traits: ["méthodique", "attentif", "patient"],
      colors: { body: "#294b58", accent: "#e4b04a", skin: "#b8795a", hair: "#292127" },
      sprite: {
        atlasRow: 0,
        animation: "desk",
        layer: "behind-desk",
        width: 136,
        height: 80,
        fixedPoint: { x: 1068, y: 520 },
      },
      routine: [
        { at: 0, point: { x: 330, y: 185 }, activity: "Saisit un dossier d'admission" },
        { at: 24, point: { x: 330, y: 185 }, activity: "Vérifie une pièce d'identité" },
        { at: 48, point: { x: 330, y: 185 }, activity: "Consulte l'écran de contrôle", line: "Le dossier 19 reste bloqué." },
        { at: 74, point: { x: 330, y: 185 }, activity: "Classe les autorisations" },
        { at: 94, point: { x: 330, y: 185 }, activity: "Reprend la saisie" },
      ],
    },
    {
      id: "aya-lin",
      name: "Aya Lin",
      role: "Agente administrative",
      clearance: "Niveau ambre",
      description:
        "Depuis le second poste, elle coordonne les arrivées et les autorisations avec le greffe.",
      traits: ["rapide", "discrète", "tenace"],
      colors: { body: "#524a69", accent: "#c8badc", skin: "#d8aa7c", hair: "#24202b" },
      sprite: {
        atlasRow: 1,
        animation: "desk",
        layer: "behind-desk",
        width: 136,
        height: 80,
        fixedPoint: { x: 1258, y: 520 },
      },
      routine: [
        { at: 0, point: { x: 365, y: 145 }, activity: "Tape une autorisation d'accès" },
        { at: 21, point: { x: 365, y: 145 }, activity: "Répond au téléphone interne" },
        { at: 46, point: { x: 365, y: 145 }, activity: "Appelle le greffe", line: "La ligne 19 n'a toujours pas de destination." },
        { at: 72, point: { x: 365, y: 145 }, activity: "Compare deux dossiers" },
        { at: 92, point: { x: 365, y: 145 }, activity: "Prépare le prochain badge" },
      ],
    },
    {
      id: "elias-venn",
      name: "Elias Venn",
      role: "Agent de contrôle",
      clearance: "Niveau vert",
      description:
        "Affecté au contrôle des visiteurs. Il connaît le bruit exact de chaque serrure de l'accueil.",
      traits: ["calme", "précis", "superstitieux"],
      colors: { body: "#30465c", accent: "#7fa8b5", skin: "#d49b74", hair: "#5d3523" },
      sprite: {
        atlasRow: 2,
        animation: "walk",
        layer: "floor",
        width: 132,
        height: 82,
      },
      routine: [
        { at: 0, point: { x: 135, y: 310 }, activity: "Teste le détecteur manuel" },
        { at: 22, point: { x: 60, y: 355 }, activity: "Accueille une visiteuse", line: "Badge visible pendant toute la visite." },
        { at: 45, point: { x: 190, y: 285 }, activity: "Vérifie les objets consignés" },
        { at: 70, point: { x: 55, y: 330 }, activity: "Surveille le sas" },
        { at: 90, point: { x: 135, y: 310 }, activity: "Renseigne la main courante" },
      ],
    },
    {
      id: "milo-serr",
      name: "Milo Serr",
      role: "Visiteur convoqué",
      clearance: "Badge temporaire",
      description:
        "Il découvre les procédures de l'accueil et vérifie trois fois chaque indication avant d'avancer.",
      traits: ["nerveux", "poli", "ponctuel"],
      colors: { body: "#815e4d", accent: "#d68a5f", skin: "#9b674e", hair: "#252324" },
      sprite: {
        atlasRow: 3,
        animation: "walk",
        layer: "floor",
        width: 132,
        height: 82,
      },
      routine: [
        { at: 0, point: { x: 500, y: 380 }, activity: "Entre dans l'accueil" },
        { at: 23, point: { x: 390, y: 310 }, activity: "Cherche le bon guichet" },
        { at: 48, point: { x: 190, y: 330 }, activity: "Passe sous le portique" },
        { at: 72, point: { x: 360, y: 230 }, activity: "Présente ses documents", line: "C'est bien ici pour le parloir ?" },
        { at: 94, point: { x: 430, y: 280 }, activity: "Attend son badge" },
      ],
    },
    {
      id: "nima-rook",
      name: "Dr Nima Rook",
      role: "Médecin visiteuse",
      clearance: "Badge temporaire",
      description:
        "Médecin remplaçante appelée à l'infirmerie. Elle attend sur la première rangée, douze minutes en avance.",
      traits: ["directe", "curieuse", "pressée"],
      colors: { body: "#486e68", accent: "#d9e7dc", skin: "#c88962", hair: "#171617" },
      sprite: {
        atlasRow: 4,
        animation: "wait",
        layer: "floor",
        width: 126,
        height: 76,
        fixedPoint: { x: 904, y: 792 },
      },
      routine: [
        { at: 0, point: { x: 520, y: 310 }, activity: "Relit son ordre de mission" },
        { at: 27, point: { x: 520, y: 310 }, activity: "Observe le guichet" },
        { at: 55, point: { x: 520, y: 310 }, activity: "Consulte sa montre", line: "L'infirmerie a demandé du renfort." },
        { at: 82, point: { x: 520, y: 310 }, activity: "Attend qu'on l'appelle" },
      ],
    },
    {
      id: "juno-vale",
      name: "Juno Vale",
      role: "Agent de maintenance",
      clearance: "Niveau vert",
      description:
        "Il entretient les zones publiques sans interrompre les contrôles et connaît tous les passages techniques.",
      traits: ["discret", "minutieux", "ingénieux"],
      colors: { body: "#b88735", accent: "#f0c65e", skin: "#8f644b", hair: "#383236" },
      sprite: {
        atlasRow: 5,
        animation: "clean",
        layer: "floor",
        width: 132,
        height: 82,
      },
      routine: [
        { at: 0, point: { x: 720, y: 100 }, activity: "Range le chariot d'entretien" },
        { at: 20, point: { x: 670, y: 40 }, activity: "Nettoie le passage latéral" },
        { at: 46, point: { x: 600, y: 55 }, activity: "Ramasse un papier oublié" },
        { at: 68, point: { x: 540, y: -50 }, activity: "Inspecte une grille au sol", line: "Cette vibration n'était pas là hier." },
        { at: 91, point: { x: 720, y: 100 }, activity: "Revient près du chariot" },
      ],
    },
  ],
};
