import type { Character, Point, SelectedEntity } from "./types";

export type IsoCharacterFrame = {
  character: Character;
  point: Point;
  activity: string;
  line?: string;
};

const ORIGIN = { x: 725, y: 370 };
const ISO_X = 1.04;
const ISO_Y = 0.52;

export function projectWorldPoint(point: Point, z = 0): Point {
  return {
    x: ORIGIN.x + (point.x - point.y) * ISO_X,
    y: ORIGIN.y + (point.x + point.y) * ISO_Y - z,
  };
}

const path = (ctx: CanvasRenderingContext2D, points: Point[], fill: string, stroke = "#8aa4a8") => {
  ctx.beginPath();
  ctx.moveTo(Math.round(points[0].x) + 0.5, Math.round(points[0].y) + 0.5);
  points.slice(1).forEach((point) => ctx.lineTo(Math.round(point.x) + 0.5, Math.round(point.y) + 0.5));
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = 1;
  ctx.stroke();
};

const line = (ctx: CanvasRenderingContext2D, points: Point[], color = "#8aa4a8", width = 1) => {
  ctx.beginPath();
  ctx.moveTo(Math.round(points[0].x) + 0.5, Math.round(points[0].y) + 0.5);
  points.slice(1).forEach((point) => ctx.lineTo(Math.round(point.x) + 0.5, Math.round(point.y) + 0.5));
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke();
};

const pixel = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  color: string,
) => {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(width), Math.round(height));
};

const text = (
  ctx: CanvasRenderingContext2D,
  value: string,
  x: number,
  y: number,
  color = "#405c63",
  size = 8,
  align: CanvasTextAlign = "left",
) => {
  ctx.font = `700 ${size}px "Courier New", monospace`;
  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgba(255,255,255,.78)";
  ctx.fillText(value, Math.round(x) + 1, Math.round(y) + 1);
  ctx.fillStyle = color;
  ctx.fillText(value, Math.round(x), Math.round(y));
};

type BoxPalette = { top: string; left: string; right: string; edge?: string };

function isoBox(
  ctx: CanvasRenderingContext2D,
  u: number,
  v: number,
  width: number,
  depth: number,
  height: number,
  colors: BoxPalette,
) {
  const a = projectWorldPoint({ x: u, y: v });
  const b = projectWorldPoint({ x: u + width, y: v });
  const c = projectWorldPoint({ x: u + width, y: v + depth });
  const d = projectWorldPoint({ x: u, y: v + depth });
  const at = projectWorldPoint({ x: u, y: v }, height);
  const bt = projectWorldPoint({ x: u + width, y: v }, height);
  const ct = projectWorldPoint({ x: u + width, y: v + depth }, height);
  const dt = projectWorldPoint({ x: u, y: v + depth }, height);
  const edge = colors.edge ?? "#78979c";
  path(ctx, [d, c, ct, dt], colors.left, edge);
  path(ctx, [b, c, ct, bt], colors.right, edge);
  path(ctx, [at, bt, ct, dt], colors.top, edge);
  return { a, b, c, d, at, bt, ct, dt };
}

function drawBackdrop(ctx: CanvasRenderingContext2D, time: number) {
  pixel(ctx, 0, 0, 1600, 1000, "#b9d8d8");
  // Distant modular corridors imply a much larger continuous floor.
  path(ctx, [
    { x: -120, y: 286 }, { x: 220, y: 116 }, { x: 407, y: 210 }, { x: 64, y: 380 },
  ], "#dbecec", "#9bb9bd");
  path(ctx, [
    { x: 1260, y: 250 }, { x: 1600, y: 420 }, { x: 1600, y: 670 }, { x: 1060, y: 401 },
  ], "#d9ebeb", "#9bb9bd");
  for (let i = 0; i < 11; i += 1) {
    const x = -40 + i * 46;
    line(ctx, [{ x, y: 300 - x * 0.5 }, { x: x + 180, y: 390 - x * 0.5 }], "#b0cacd");
  }
  for (let i = 0; i < 10; i += 1) {
    const x = 1210 + i * 52;
    line(ctx, [{ x, y: 285 + (x - 1210) * 0.5 }, { x: x - 180, y: 375 + (x - 1210) * 0.5 }], "#aec8cb");
  }
  const tinyLight = Math.floor(time * 3) % 2 ? "#ee6d6f" : "#9eced0";
  pixel(ctx, 1433, 322, 4, 4, tinyLight);
  pixel(ctx, 165, 189, 4, 4, "#eabf54");
}

function drawFloor(ctx: CanvasRenderingContext2D) {
  const o = projectWorldPoint({ x: 0, y: 0 });
  const u = projectWorldPoint({ x: 650, y: 0 });
  const uv = projectWorldPoint({ x: 650, y: 420 });
  const v = projectWorldPoint({ x: 0, y: 420 });
  path(ctx, [o, u, uv, v], "#d7e8e6", "#8faeb2");

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(o.x, o.y);
  ctx.lineTo(u.x, u.y);
  ctx.lineTo(uv.x, uv.y);
  ctx.lineTo(v.x, v.y);
  ctx.closePath();
  ctx.clip();
  for (let tileU = 0; tileU <= 650; tileU += 16) {
    line(ctx, [projectWorldPoint({ x: tileU, y: 0 }), projectWorldPoint({ x: tileU, y: 420 })], tileU % 64 ? "#c2d9d8" : "#adc9ca");
  }
  for (let tileV = 0; tileV <= 420; tileV += 16) {
    line(ctx, [projectWorldPoint({ x: 0, y: tileV }), projectWorldPoint({ x: 650, y: tileV })], tileV % 64 ? "#c3dbd9" : "#adc9ca");
  }
  // Tiny wear, drain covers and route markings.
  for (const [u0, v0] of [[70, 240], [205, 340], [390, 90], [540, 315], [608, 155]] as const) {
    const p = projectWorldPoint({ x: u0, y: v0 });
    pixel(ctx, p.x - 2, p.y - 1, 4, 2, "#9ebfc0");
  }
  ctx.restore();

  const guideA = projectWorldPoint({ x: 205, y: 305 });
  const guideB = projectWorldPoint({ x: 510, y: 305 });
  line(ctx, [guideA, guideB], "#e5b943", 2);
  for (let u0 = 220; u0 < 510; u0 += 28) {
    line(ctx, [projectWorldPoint({ x: u0, y: 302 }), projectWorldPoint({ x: u0 + 12, y: 302 })], "#fff1a8", 2);
  }
}

function drawRearWalls(ctx: CanvasRenderingContext2D, time: number) {
  const wallHeight = 230;
  // North-east wall.
  const a = projectWorldPoint({ x: 0, y: 0 });
  const b = projectWorldPoint({ x: 650, y: 0 });
  const at = projectWorldPoint({ x: 0, y: 0 }, wallHeight);
  const bt = projectWorldPoint({ x: 650, y: 0 }, wallHeight);
  path(ctx, [at, bt, b, a], "#eaf5f2", "#91afb4");
  // North-west wall.
  const c = projectWorldPoint({ x: 0, y: 420 });
  const ct = projectWorldPoint({ x: 0, y: 420 }, wallHeight);
  path(ctx, [at, a, c, ct], "#dcefed", "#91afb4");

  // One-pixel wall panel rhythm and metal uprights.
  for (let u0 = 0; u0 <= 650; u0 += 32) {
    line(ctx, [projectWorldPoint({ x: u0, y: 0 }), projectWorldPoint({ x: u0, y: 0 }, wallHeight)], u0 % 96 ? "#c5dddc" : "#9ebdc0");
  }
  for (let v0 = 0; v0 <= 420; v0 += 32) {
    line(ctx, [projectWorldPoint({ x: 0, y: v0 }), projectWorldPoint({ x: 0, y: v0 }, wallHeight)], v0 % 96 ? "#c3dcdb" : "#9ebdc0");
  }
  for (const z of [38, 158]) {
    line(ctx, [projectWorldPoint({ x: 0, y: 0 }, z), projectWorldPoint({ x: 650, y: 0 }, z)], "#a7c4c5");
    line(ctx, [projectWorldPoint({ x: 0, y: 0 }, z), projectWorldPoint({ x: 0, y: 420 }, z)], "#a7c4c5");
  }

  // Fine colored service pipes run around both walls.
  for (const [z, color] of [[202, "#7ab18d"], [190, "#d9b777"], [178, "#81aeb7"]] as const) {
    line(ctx, [projectWorldPoint({ x: 12, y: 0 }, z), projectWorldPoint({ x: 636, y: 0 }, z)], color, 3);
    line(ctx, [projectWorldPoint({ x: 0, y: 12 }, z), projectWorldPoint({ x: 0, y: 406 }, z)], color, 3);
  }
  for (let u0 = 38; u0 < 640; u0 += 92) {
    const p = projectWorldPoint({ x: u0, y: 0 }, 191);
    pixel(ctx, p.x - 2, p.y - 4, 5, 9, "#879fa0");
  }

  // Ceiling trusses only, leaving the room fully observable.
  for (const v0 of [48, 210, 374]) {
    line(ctx, [projectWorldPoint({ x: 0, y: v0 }, 235), projectWorldPoint({ x: 650, y: v0 }, 235)], "#9eb8ba", 3);
    for (let u0 = 25; u0 < 650; u0 += 42) {
      line(ctx, [projectWorldPoint({ x: u0, y: v0 }, 231), projectWorldPoint({ x: u0 + 15, y: v0 }, 239)], "#c5d7d6");
    }
  }
  // Small fluorescent strips.
  for (const [u0, v0] of [[150, 70], [390, 70], [270, 280], [520, 280]] as const) {
    const p1 = projectWorldPoint({ x: u0, y: v0 }, 226);
    const p2 = projectWorldPoint({ x: u0 + 62, y: v0 }, 226);
    line(ctx, [p1, p2], "#fff9ce", 5);
    line(ctx, [p1, p2], "#f5e6a0", 1);
  }

  // Camera LEDs.
  const camera = projectWorldPoint({ x: 80, y: 0 }, 150);
  pixel(ctx, camera.x - 12, camera.y - 7, 24, 10, "#758d91");
  pixel(ctx, camera.x + 8, camera.y - 3, 8, 5, "#304b55");
  pixel(ctx, camera.x - 8, camera.y - 3, 3, 3, Math.floor(time * 2) % 2 ? "#e76262" : "#953e46");
}

function wallPanel(
  ctx: CanvasRenderingContext2D,
  u: number,
  z: number,
  width: number,
  height: number,
  fill: string,
) {
  const a = projectWorldPoint({ x: u, y: 0 }, z);
  const b = projectWorldPoint({ x: u + width, y: 0 }, z);
  const bt = projectWorldPoint({ x: u + width, y: 0 }, z + height);
  const at = projectWorldPoint({ x: u, y: 0 }, z + height);
  path(ctx, [at, bt, b, a], fill, "#78999f");
  return { a, b, bt, at };
}

function leftWallPanel(
  ctx: CanvasRenderingContext2D,
  v: number,
  z: number,
  width: number,
  height: number,
  fill: string,
) {
  const a = projectWorldPoint({ x: 0, y: v }, z);
  const b = projectWorldPoint({ x: 0, y: v + width }, z);
  const bt = projectWorldPoint({ x: 0, y: v + width }, z + height);
  const at = projectWorldPoint({ x: 0, y: v }, z + height);
  path(ctx, [at, a, b, bt], fill, "#78999f");
  return { a, b, bt, at };
}

function drawWallDetails(ctx: CanvasRenderingContext2D, time: number) {
  // Movement board.
  const board = wallPanel(ctx, 165, 67, 128, 90, "#345a65");
  const boardCenter = { x: (board.at.x + board.b.x) / 2, y: (board.at.y + board.b.y) / 2 };
  text(ctx, "MOUVEMENTS", boardCenter.x, boardCenter.y - 31, "#ffe078", 8, "center");
  [["06:42", "A318"], ["07:10", "T044"], ["--:--", Math.floor(time * 2) % 2 ? "L019" : "????"]].forEach((row, index) => {
    text(ctx, row[0], boardCenter.x - 35, boardCenter.y - 12 + index * 15, "#9ee2d6", 7);
    text(ctx, row[1], boardCenter.x + 12, boardCenter.y - 12 + index * 15, index === 2 ? "#ff9b85" : "#f1f1cf", 7);
  });

  // Main secure door A-01.
  const door = wallPanel(ctx, 330, 0, 112, 181, "#b8d1d1");
  const mid = { x: (door.at.x + door.b.x) / 2, y: (door.at.y + door.b.y) / 2 };
  line(ctx, [{ x: mid.x, y: mid.y - 84 }, { x: mid.x, y: mid.y + 88 }], "#78999f");
  line(ctx, [{ x: mid.x - 54, y: mid.y - 40 }, { x: mid.x + 54, y: mid.y + 14 }], "#c7dddd");
  pixel(ctx, mid.x - 34, mid.y + 12, 4, 13, "#6e9295");
  pixel(ctx, mid.x + 29, mid.y + 43, 4, 13, "#6e9295");
  const doorSign = projectWorldPoint({ x: 374, y: 0 }, 193);
  text(ctx, "A—01", doorSign.x, doorSign.y, "#bd6b57", 9, "center");
  const access = projectWorldPoint({ x: 450, y: 0 }, 108);
  pixel(ctx, access.x - 3, access.y - 9, 12, 19, "#76979a");
  pixel(ctx, access.x, access.y - 6, 5, 5, Math.floor(time * 3) % 13 ? "#75c997" : "#efb552");

  // Visitor lockers: 24 tiny individually outlined doors.
  wallPanel(ctx, 470, 24, 148, 142, "#c3d9d7");
  for (let row = 0; row < 6; row += 1) {
    for (let col = 0; col < 4; col += 1) {
      const u = 476 + col * 35;
      const z = 30 + row * 21;
      const panel = wallPanel(ctx, u, z, 31, 18, row === 4 && col === 2 ? "#e0a39a" : "#d9e6df");
      const center = { x: (panel.at.x + panel.b.x) / 2, y: (panel.at.y + panel.b.y) / 2 };
      pixel(ctx, center.x + 7, center.y, 2, 2, row === 4 && col === 2 ? "#da5b5c" : "#bd9d55");
    }
  }

  // Left-wall posters, fire cabinet and tally marks.
  const poster = leftWallPanel(ctx, 55, 66, 73, 104, "#f2df9d");
  const posterCenter = { x: (poster.at.x + poster.b.x) / 2, y: (poster.at.y + poster.b.y) / 2 };
  text(ctx, "TOUT", posterCenter.x, posterCenter.y - 20, "#527e82", 8, "center");
  text(ctx, "COMPTE", posterCenter.x, posterCenter.y - 5, "#c86758", 8, "center");
  for (let i = 0; i < 5; i += 1) pixel(ctx, posterCenter.x - 25 + i * 10, posterCenter.y + 14, 4, 11 + (i % 2) * 4, "#66827f");

  leftWallPanel(ctx, 146, 44, 50, 90, "#db7163");
  const fire = projectWorldPoint({ x: 0, y: 171 }, 88);
  pixel(ctx, fire.x - 11, fire.y - 22, 22, 41, "#f2e8cc");
  pixel(ctx, fire.x - 6, fire.y - 15, 12, 28, "#c54f49");

  for (let i = 0; i < 8; i += 1) {
    const mark = projectWorldPoint({ x: 0, y: 250 + (i % 2) * 5 }, 46 + i * 10);
    line(ctx, [{ x: mark.x - 2, y: mark.y - 5 }, { x: mark.x + 3, y: mark.y + 5 }], "#78999c");
  }

  // Wall clock.
  const clock = projectWorldPoint({ x: 310, y: 0 }, 194);
  ctx.fillStyle = "#fff4c9";
  ctx.beginPath();
  ctx.arc(clock.x, clock.y, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#77989b";
  ctx.lineWidth = 1;
  ctx.stroke();
  line(ctx, [clock, { x: clock.x + Math.cos(time * .35) * 9, y: clock.y + Math.sin(time * .35) * 9 }], "#536f73");
  line(ctx, [clock, { x: clock.x - 6, y: clock.y - 5 }], "#536f73");
}

function drawSecurity(ctx: CanvasRenderingContext2D, time: number) {
  // X-ray conveyor with transparent, fine geometry.
  isoBox(ctx, 32, 255, 175, 38, 31, { top: "#b7d4d2", left: "#9ebfc0", right: "#8fb2b6" });
  isoBox(ctx, 39, 263, 67, 27, 83, { top: "#c3ddda", left: "#a8c7c6", right: "#93b7ba" });
  const screen = projectWorldPoint({ x: 47, y: 292 }, 61);
  path(ctx, [
    { x: screen.x - 20, y: screen.y - 15 }, { x: screen.x + 22, y: screen.y + 6 },
    { x: screen.x + 22, y: screen.y + 29 }, { x: screen.x - 20, y: screen.y + 8 },
  ], "#466d76", "#718f94");
  line(ctx, [{ x: screen.x - 13, y: screen.y }, { x: screen.x + 11 + (time * 5) % 13, y: screen.y + 12 }], "#7be0cf");
  for (let u = 115; u < 202; u += 15) {
    const p = projectWorldPoint({ x: u, y: 274 }, 33);
    line(ctx, [{ x: p.x - 8, y: p.y - 4 }, { x: p.x + 8, y: p.y + 4 }], "#76989d");
  }

  // Walk-through detector: thin columns, not a chunky cubic arch.
  const gateU = 165;
  const gateV = 315;
  const left = projectWorldPoint({ x: gateU, y: gateV });
  const right = projectWorldPoint({ x: gateU + 52, y: gateV });
  line(ctx, [left, projectWorldPoint({ x: gateU, y: gateV }, 117)], "#628c93", 6);
  line(ctx, [right, projectWorldPoint({ x: gateU + 52, y: gateV }, 117)], "#628c93", 6);
  line(ctx, [projectWorldPoint({ x: gateU, y: gateV }, 117), projectWorldPoint({ x: gateU + 52, y: gateV }, 117)], "#87aeb0", 8);
  line(ctx, [projectWorldPoint({ x: gateU, y: gateV }, 112), projectWorldPoint({ x: gateU + 52, y: gateV }, 112)], "#d4e5df", 2);
  const led = projectWorldPoint({ x: gateU + 38, y: gateV }, 116);
  pixel(ctx, led.x, led.y - 2, 3, 3, Math.floor(time * 5) % 23 ? "#61c88b" : "#ed6862");

  // Trays on slender stands.
  for (let i = 0; i < 3; i += 1) {
    isoBox(ctx, 76 + i * 35, 326, 27, 18, 4, { top: i === 1 ? "#e6bb75" : "#a9cacc", left: "#8eb5b8", right: "#7ea5aa" });
  }
}

function drawDesk(ctx: CanvasRenderingContext2D, time: number) {
  // Reception counter follows the iso grid with a curved impression created by staggered sections.
  isoBox(ctx, 230, 112, 238, 68, 58, { top: "#d6bd8a", left: "#a8bdb2", right: "#8daaa8" });
  isoBox(ctx, 440, 151, 62, 92, 58, { top: "#cbb384", left: "#9eb7ad", right: "#819f9f" });
  for (let u = 247; u < 447; u += 42) {
    const seamA = projectWorldPoint({ x: u, y: 180 });
    const seamB = projectWorldPoint({ x: u, y: 180 }, 48);
    line(ctx, [seamA, seamB], "#7f9ea0");
  }

  // Tiny monitors, folders, mug and desk lamp.
  for (const [u, color] of [[276, "#72cabb"], [373, "#e4af57"]] as const) {
    const p = projectWorldPoint({ x: u, y: 132 }, 93);
    path(ctx, [
      { x: p.x - 24, y: p.y - 18 }, { x: p.x + 24, y: p.y - 6 },
      { x: p.x + 24, y: p.y + 21 }, { x: p.x - 24, y: p.y + 9 },
    ], "#44666f", "#719095");
    line(ctx, [{ x: p.x - 17, y: p.y - 8 }, { x: p.x + 13 + (time * 4) % 9, y: p.y }], color, 2);
    line(ctx, [{ x: p.x - 17, y: p.y }, { x: p.x + 6, y: p.y + 6 }], "#a3c2bd");
    pixel(ctx, p.x - 2, p.y + 18, 4, 11, "#668487");
  }
  for (let i = 0; i < 5; i += 1) {
    const p = projectWorldPoint({ x: 330 + i * 9, y: 150 - i * 2 }, 64);
    line(ctx, [{ x: p.x - 18, y: p.y - 4 }, { x: p.x + 18, y: p.y + 5 }], i % 2 ? "#f4e9bf" : "#9ac9b7", 3);
  }
  const mug = projectWorldPoint({ x: 449, y: 182 }, 66);
  pixel(ctx, mug.x - 4, mug.y - 9, 8, 10, "#cf6a59");
  pixel(ctx, mug.x + 4, mug.y - 7, 4, 5, "#cf6a59");
  for (let i = 0; i < 2; i += 1) {
    const drift = Math.sin(time * 2 + i) * 2;
    line(ctx, [{ x: mug.x + drift, y: mug.y - 11 - i * 6 }, { x: mug.x - drift, y: mug.y - 15 - i * 6 }], "rgba(255,255,255,.7)");
  }
  const deskLabel = projectWorldPoint({ x: 344, y: 181 }, 31);
  text(ctx, "ADMISSIONS", deskLabel.x, deskLabel.y, "#476a6d", 8, "center");

  // Pneumatic tube and moving capsule.
  const tubeBottom = projectWorldPoint({ x: 492, y: 128 }, 58);
  const tubeTop = projectWorldPoint({ x: 492, y: 128 }, 186);
  line(ctx, [tubeBottom, tubeTop], "#83a9aa", 7);
  line(ctx, [tubeBottom, tubeTop], "#d8e8df", 2);
  const capsuleY = tubeBottom.y - 16 - ((time * 14) % 91);
  pixel(ctx, tubeBottom.x - 3, capsuleY, 6, 15, "#df8864");
}

function drawWaitingArea(ctx: CanvasRenderingContext2D, time: number) {
  // Slender benches with repeated slats.
  for (const [u, v] of [[430, 255], [485, 310], [390, 350]] as const) {
    isoBox(ctx, u, v, 112, 28, 13, { top: "#b88e68", left: "#8aa5a2", right: "#78979a" });
    for (let slat = 0; slat < 4; slat += 1) {
      line(ctx, [projectWorldPoint({ x: u + 8 + slat * 26, y: v + 4 }, 14), projectWorldPoint({ x: u + 8 + slat * 26, y: v + 24 }, 14)], "#d2aa76");
    }
    line(ctx, [projectWorldPoint({ x: u + 13, y: v + 12 }), projectWorldPoint({ x: u + 13, y: v + 12 }, -18)], "#718e91", 2);
    line(ctx, [projectWorldPoint({ x: u + 96, y: v + 12 }), projectWorldPoint({ x: u + 96, y: v + 12 }, -18)], "#718e91", 2);
  }

  // Queue poles and belt.
  for (const [u, v] of [[290, 276], [370, 276], [450, 276]] as const) {
    const p = projectWorldPoint({ x: u, y: v });
    const top = projectWorldPoint({ x: u, y: v }, 39);
    line(ctx, [p, top], "#78989a", 2);
    ctx.fillStyle = "#e7bf62";
    ctx.beginPath();
    ctx.arc(top.x, top.y, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  line(ctx, [projectWorldPoint({ x: 290, y: 276 }, 37), projectWorldPoint({ x: 450, y: 276 }, 37)], "#cf6b5b", 2);

  // Queue ticket dispenser and first-aid cabinet.
  isoBox(ctx, 554, 200, 34, 26, 72, { top: "#f0d594", left: "#d7e3d8", right: "#a7c3c0" });
  const queue = projectWorldPoint({ x: 572, y: 226 }, 48);
  pixel(ctx, queue.x - 8, queue.y - 8, 16, 10, "#45666e");
  text(ctx, String(18 + (Math.floor(time / 9) % 3)), queue.x, queue.y - 3, "#ffe174", 7, "center");
  const aid = wallPanel(ctx, 624, 52, 24, 43, "#f8faf1");
  const aidCenter = { x: (aid.at.x + aid.b.x) / 2, y: (aid.at.y + aid.b.y) / 2 };
  pixel(ctx, aidCenter.x - 6, aidCenter.y - 2, 12, 4, "#e6645c");
  pixel(ctx, aidCenter.x - 2, aidCenter.y - 6, 4, 12, "#e6645c");

  // Lost photograph.
  const photo = projectWorldPoint({ x: 505, y: 350 }, 1);
  ctx.save();
  ctx.translate(photo.x, photo.y);
  ctx.rotate(.17);
  pixel(ctx, -9, -6, 18, 12, "#f2e4b5");
  pixel(ctx, -7, -4, 14, 7, "#75a8a3");
  ctx.restore();
}

function drawMicroLife(ctx: CanvasRenderingContext2D, time: number) {
  // An original autonomous floor-cleaning unit.
  const botU = 265 + (Math.sin(time * .45) + 1) * 48;
  const bot = projectWorldPoint({ x: botU, y: 380 });
  ctx.fillStyle = "rgba(74,103,103,.2)";
  ctx.beginPath();
  ctx.ellipse(bot.x + 3, bot.y + 5, 15, 6, .45, 0, Math.PI * 2);
  ctx.fill();
  path(ctx, [
    { x: bot.x - 12, y: bot.y - 6 }, { x: bot.x + 9, y: bot.y + 4 },
    { x: bot.x + 13, y: bot.y + 13 }, { x: bot.x - 8, y: bot.y + 3 },
  ], "#e8cc66", "#708f92");
  pixel(ctx, bot.x - 3, bot.y - 7, 13, 7, "#7ba7a5");
  pixel(ctx, bot.x + 5, bot.y - 4, 2, 2, "#58d3b2");

  // Scattered papers and a floor drain add scale.
  for (const [u, v, color] of [[214, 218, "#f5ecc8"], [585, 350, "#f0d0a1"], [354, 396, "#c9e0d6"]] as const) {
    const p = projectWorldPoint({ x: u, y: v }, 1);
    path(ctx, [
      { x: p.x - 7, y: p.y - 4 }, { x: p.x + 8, y: p.y + 1 },
      { x: p.x + 5, y: p.y + 7 }, { x: p.x - 9, y: p.y + 2 },
    ], color, "#a7b9ae");
  }
  const drain = projectWorldPoint({ x: 350, y: 355 });
  path(ctx, [
    { x: drain.x - 17, y: drain.y - 8 }, { x: drain.x + 17, y: drain.y + 8 },
    { x: drain.x + 7, y: drain.y + 13 }, { x: drain.x - 26, y: drain.y - 3 },
  ], "#8eaaab", "#66878c");
  for (let i = 0; i < 5; i += 1) line(ctx, [{ x: drain.x - 18 + i * 7, y: drain.y - 6 + i * 3 }, { x: drain.x - 11 + i * 7, y: drain.y + 10 + i * 3 }], "#6e8e91");
}

function drawCharacter(
  ctx: CanvasRenderingContext2D,
  frame: IsoCharacterFrame,
  selected: boolean,
  showLabel: boolean,
  time: number,
) {
  const { character, point } = frame;
  const moving = frame.activity.startsWith("Se déplace");
  const phase = Math.sin(time * 10 + character.id.length);
  const step = moving ? (phase > 0 ? 1 : -1) : 0;
  const x = Math.round(point.x);
  const y = Math.round(point.y - (moving && phase > 0 ? 1 : 0));

  ctx.fillStyle = "rgba(77,105,104,.18)";
  ctx.beginPath();
  ctx.ellipse(x + 3, y + 5, 10, 4, .45, 0, Math.PI * 2);
  ctx.fill();

  if (selected) {
    ctx.strokeStyle = "#df7c5e";
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 2]);
    ctx.beginPath();
    ctx.ellipse(x, y + 3, 14, 7, .45, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // 1 px outline around a tiny, softer sprite.
  pixel(ctx, x - 6, y - 26, 13, 25, "#486267");
  pixel(ctx, x - 5, y - 25, 11, 23, character.colors.body);
  pixel(ctx, x - 8, y - 22, 3, 14, character.colors.body);
  pixel(ctx, x + 6, y - 22, 3, 14, character.colors.body);
  pixel(ctx, x - 5, y - 30, 11, 5, character.colors.accent);
  pixel(ctx, x - 5, y - 39, 11, 10, character.colors.skin);
  pixel(ctx, x - 6, y - 42, 13, 5, character.colors.hair);
  pixel(ctx, x - 3, y - 35, 1, 1, "#35464a");
  pixel(ctx, x + 3, y - 35, 1, 1, "#35464a");
  pixel(ctx, x - 5, y - 2, 4, 8 + step, "#4e6468");
  pixel(ctx, x + 2, y - 2, 4, 8 - step, "#4e6468");
  if (character.role.includes("surveillance") || character.role.includes("contrôle")) pixel(ctx, x + 2, y - 22, 3, 3, "#f4c75e");

  if (showLabel || selected) {
    const width = Math.max(62, character.name.length * 6 + 10);
    pixel(ctx, x - width / 2, y - 57, width, 14, "rgba(245,250,237,.9)");
    pixel(ctx, x - width / 2, y - 57, 2, 14, character.colors.accent);
    text(ctx, character.name, x, y - 50, "#426064", 8, "center");
  }

  if (frame.line) {
    const width = Math.max(112, Math.min(220, frame.line.length * 6 + 18));
    pixel(ctx, x - width / 2, y - 88, width, 23, "#fff7d8");
    pixel(ctx, x - width / 2 + 8, y - 65, 7, 4, "#fff7d8");
    text(ctx, frame.line, x, y - 76, "#536765", 8, "center");
  }
}

export function drawIsometricReception(
  ctx: CanvasRenderingContext2D,
  time: number,
  frames: IsoCharacterFrame[],
  selected: SelectedEntity | null,
  showLabels: boolean,
) {
  drawBackdrop(ctx, time);
  drawFloor(ctx);
  drawRearWalls(ctx, time);
  drawWallDetails(ctx, time);
  drawDesk(ctx, time);
  drawSecurity(ctx, time);
  drawWaitingArea(ctx, time);
  drawMicroLife(ctx, time);

  frames
    .slice()
    .sort((a, b) => a.point.y - b.point.y)
    .forEach((frame) =>
      drawCharacter(
        ctx,
        frame,
        selected?.kind === "character" && selected.character.id === frame.character.id,
        showLabels,
        time,
      ),
    );

  // Fine cutaway edges and expansion arrows.
  line(ctx, [projectWorldPoint({ x: 0, y: 420 }), projectWorldPoint({ x: 650, y: 420 })], "#83a5a8", 2);
  line(ctx, [projectWorldPoint({ x: 650, y: 0 }), projectWorldPoint({ x: 650, y: 420 })], "#83a5a8", 2);
  const publicLabel = projectWorldPoint({ x: 0, y: 392 }, 18);
  text(ctx, "← SAS PUBLIC", publicLabel.x - 55, publicLabel.y + 28, "#b96556", 9, "center");
  const eastLabel = projectWorldPoint({ x: 650, y: 220 }, 18);
  text(ctx, "AILE EST →", eastLabel.x + 62, eastLabel.y + 25, "#b96556", 9, "center");
}
